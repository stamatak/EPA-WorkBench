/*
 * 
 */
package wombat.net;

import net.jxta.platform.NetworkConfigurator;

public class JXTATest {
	public static void main(String[] args) {
//		NetworkConfigurator cfg = new Ne
		
	}
}
