package ml;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

public class BipartitionScore {

	HashMap <String, HashMap<String,Float>> branch_query_PlacementsBeneath = new HashMap<String, HashMap<String,Float>>(); 
	HashMap <String,Double> location_confidence = new HashMap<String, Double>();
	HashMap <String,Integer> location_branchesBeneath = new HashMap<String, Integer>();
	int all_branches = 0;
	
	public BipartitionScore(LN root, ClassificationLikelihoodParser clp){
		getNodesPlacements(root,clp);
		Set <String> branches = branch_query_PlacementsBeneath.keySet();
		for (String branch : branches){
			Set<String> queries = branch_query_PlacementsBeneath.get(branch).keySet();
			float score = 0.0f;
			// values for binomial distribution p,n,k
			float p = (float)location_branchesBeneath.get(branch)/(float)(all_branches-1);
			if (branch == "IROOT"){
				p = 1.0f;
			}
			for(String query : queries){
				HashMap<String,Double> branches_with_placements = clp.getLocationsWeights(query);
				
				float n = 0.0f;
				if (branches_with_placements.containsKey(branch)){
					n = clp.getNameLocations(query).size()+1.0f;
				}
				else{
					n = clp.getNameLocations(query).size();
				}
				float k = branch_query_PlacementsBeneath.get(branch).get(query);
				float conf = calculateConfs(p, n, k);
				if (conf > 1.0001f){
				System.out.println("n: "+n+" , k: "+k+" , p: "+p+ " => "+conf+" "+query+"("+n+")" );
				}	
				score += conf;
				
			}
			location_confidence.put(branch, Double.valueOf(score)/((double)queries.size()));
		}
		
	}
	
	// gets the amount of placements for all node's underlying subtree and counts all branches of the tree
	private void getNodesPlacements(LN node, ClassificationLikelihoodParser clp){
		all_branches++;
		HashMap <String,Float> query_placements = new HashMap<String, Float>(); // amount of placements that lie in the beneath subtree
		Set <String>  queries = clp.getNames().keySet();
		getAmountOfBranches(node,node.backLabel, clp);
		for (String query : queries){	
			float placements =  (float)getAmountOfPlacements(node,node.backLabel, clp, query,0);
			query_placements.put(query, placements);
		}
		branch_query_PlacementsBeneath.put(node.backLabel, query_placements);
		
		if (node.next.back != null){
			getNodesPlacements(node.next.back, clp);
		}
		if (node.next.next.back != null){
			getNodesPlacements(node.next.next.back, clp);
		}
	}
	
	// calculate the confidence scores based on a binomial distribution and the observed placements k for one of the subtrees
	private float calculateConfs( float p, float n, float k ){
		float conf = 0.0f;
		float lh_mass = 0.0f;
		for (int i = 0; i <= (int) k; i++){
			lh_mass += (float)(binomialCoefficient(n,i)*Math.pow((double)p, (double)i)*Math.pow(1.0-(double)p, (double)(n-i)));
		}
		if (lh_mass > 0.5){
			lh_mass = 1.0f-lh_mass;
		}
		
		conf = 1.0f - (lh_mass*2);
//		if (k == 32.0f && n == 32.0f && p > 0.5f && p < 0.8f){
//			p = 0.1f;
//			lh_mass = 0.0f;
//			for (int i = 0; i <= (int) k; i++){
//				System.out.println(i+ " => "+(float)(binomialCoefficient(n,i))+" "+((float)(binomialCoefficient(n,i)*Math.pow((double)p, (double)i)*Math.pow(1.0f-(double)p, (double)(n-i)))));
//				lh_mass += (float)(binomialCoefficient(n,i)*Math.pow((double)p, (double)i)*Math.pow(1.0f-(double)p, (double)(n-i)));
//				//System.out.println(lh_mass);
//				//System.out.println();
//			}
//			System.out.println("n: "+n+" , k: "+k+" , p: "+p+ " => "+lh_mass+" "+"("+n+")" );
//		}
		
		return conf;		
	}
	
	private float binomialCoefficient(float n, float k){
		long binom = 1;
		if (k > n/2){
			k = n-k;
		}
		for(int i = 1; i <= k; i++){
			binom *= (n+1-(float)i)/(float)i;
		}
		return (float)binom;
	}
	
	private int getAmountOfPlacements(LN node, String branch, ClassificationLikelihoodParser clp, String query, int amount){
		if (clp.getLocationsWeights(query).containsKey(node.backLabel)){
			amount++;
		}
		if (node.next.back != null){
			amount = getAmountOfPlacements(node.next.back, branch, clp, query, amount);
		}
		if (node.next.next.back != null){
			amount = getAmountOfPlacements(node.next.next.back, branch, clp, query, amount);
		}
		return amount;
	}
	
	private void getAmountOfBranches(LN node, String branch, ClassificationLikelihoodParser clp){
		if (location_branchesBeneath.containsKey(branch)){
			location_branchesBeneath.put(branch,location_branchesBeneath.get(branch)+1);
		}
		else {
			location_branchesBeneath.put(branch,1);
		}
		if (node.next.back != null){
			getAmountOfBranches(node.next.back, branch, clp);
		}
		if (node.next.next.back != null){
			 getAmountOfBranches(node.next.next.back, branch, clp);
		}
	}
	
	public HashMap <String,Double> getLocationConfidence(){
		return location_confidence;
	}
}
