package ml;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.NoSuchElementException;
import java.util.Random;
import java.util.Set;
import java.util.StringTokenizer;

public class ClassificationParser {
	private ArrayList<ArrayList<String>> data = new ArrayList<ArrayList<String>>();
	private HashMap <String,ArrayList<String>> location_name = new HashMap<String, ArrayList<String>>();
	private HashMap <String,ArrayList<Double>> location_weight = new HashMap<String, ArrayList<Double>>();
	private HashMap <String,HashMap<String,String>> location_annotation = new HashMap<String, HashMap<String,String>>();
	private HashMap <String,Integer> location_inserts = new HashMap <String,Integer>();
	private HashMap <String,Double> location_branchThickness = new HashMap <String,Double>();
	private HashMap <String,Double> location_confidence = new HashMap <String,Double>();
	private HashMap <String,HashMap<String,Double>> name_locations_weights = new HashMap <String,HashMap<String,Double>>();
	private HashMap <String,String> names = new HashMap<String,String>();
	private HashMap <String, Integer> name_inserts = new HashMap<String, Integer>();
	private int max_inserts = 0;
	
	
	
	public ClassificationParser(File f, int bootstrap_samples){
		
		try {
			BufferedReader in = new BufferedReader(new FileReader(f));
			String line = null;
			while ((line = in.readLine()) != null) {
				StringTokenizer ts = new StringTokenizer(line);
				try {
					ArrayList <String> nlc = new ArrayList<String>();
					String name = ts.nextToken();
					String location = ts.nextToken();
					String confidence = ts.nextToken();
					nlc.add(name); nlc.add(location); nlc.add(String.valueOf(Double.valueOf(confidence) / (double) bootstrap_samples));
					this.data.add(nlc);
				
				} catch( NoSuchElementException x ) {
					x.printStackTrace();
					throw new RuntimeException( "failed to parse line from classfile: " + line );
				}
			}								
		} catch (IOException e) {
			e.printStackTrace();
		}
		collectData();
		
	}	
	public ClassificationParser(ArrayList<ArrayList<String>> data){ //bootstrap confidences should be already calculated 
		this.data = data;
		collectData();
	}
	
	private void collectData(){
		location_name.clear();
		location_annotation.clear();
		location_inserts.clear();
		location_branchThickness.clear();
		location_confidence.clear();
		name_locations_weights.clear();
		location_weight.clear();
		names.clear();
		name_inserts.clear();
		Integer labels = 0;
		max_inserts = 0;
		HashMap <String,Double> location_sum_of_confidence = new HashMap <String,Double>();
		HashMap <String,Double> locations_confidence = new HashMap<String,Double>();
		
		
		for (int i = 0; i< data.size(); i++){
			String name = data.get(i).get(0);
			String location = data.get(i).get(1);
			String confidence = data.get(i).get(2);
			if (this.location_name.containsKey(location)){
				this.location_name.get(location).add(name);
				this.location_weight.get(location).add(Double.valueOf(confidence));
				this.location_inserts.put(location, this.location_inserts.get(location)+1);
				location_sum_of_confidence.put(location,location_sum_of_confidence.get(location)+Double.valueOf(confidence));
				this.location_annotation.get(location).put(name, "");
			}
			else
			{
				ArrayList <String> names = new ArrayList<String>();
				names.add(name);
				ArrayList <Double> weights = new ArrayList<Double>();
				weights.add(Double.valueOf(confidence));
				this.location_name.put(location, names);
				this.location_weight.put(location, weights);
				this.location_inserts.put(location, 1);
				HashMap<String,String> tmp = new HashMap<String, String>();
				tmp.put(name, "");
				this.location_annotation.put(location, tmp);
				location_sum_of_confidence.put(location,Double.valueOf(confidence));
				labels = labels+1;	
			}
			if (!(this.name_locations_weights.containsKey(name))){
				HashMap<String,Double> tmp = new HashMap<String, Double>();
				this.name_locations_weights.put(name, tmp);
			}
			this.name_locations_weights.get(name).put(location, Double.valueOf(confidence));
			this.names.put(name,name);
		}
		Set <String> keys = this.location_inserts.keySet();
		for (String key : keys){
			int v = this.location_inserts.get(key).intValue();
			if (v > max_inserts) {
				max_inserts = v; 
			}
			
		}
		
		double thickness = 20.0 / ((double)max_inserts);
		for (String key : keys){
			double thickness_weight = 1.0;
			for(int i = 0; i< this.location_name.get(key).size();i++){
				thickness_weight = thickness_weight + this.name_locations_weights.get(this.location_name.get(key).get(i)).get(key);
			}
			this.location_branchThickness.put(key, 1.0 + thickness*thickness_weight );
			this.location_confidence.put(key, location_sum_of_confidence.get(key)/(this.location_inserts.get(key).doubleValue()));
//			System.out.println(location_confidence.get(key));
		}
	}
	
	public int getHighestAmountOfInserts(){
		return data.size();
		//return max_inserts;
	}
	public HashMap <String,ArrayList<String>>getLocationName(){
		return this.location_name;
	}
	public HashMap <String,Integer> getLocationInserts(){
		return this.location_inserts;
	}
	public HashMap <String,Double>  getLocationBranchThickness(){
		return this.location_branchThickness;
	}
	public HashMap <String,Double> getLocationConfidence(){
		return this.location_confidence;
	}
	public HashMap<String,String> getNames(){
		return this.names;
	}
	
	public ArrayList<String> getNameLocations(String name){
		ArrayList <String> locations = new ArrayList<String>();
		Set <String> locis = this.name_locations_weights.get(name).keySet();
		for (String k : locis){
			locations.add(k);
		}
		return locations;
	}
	
	public ArrayList<ArrayList<String>>  getData(){
		return this.data;
	}
	
	public HashMap<String,Double> getLocationsWeights(String query_name){
		HashMap<String,Double> locations_weights = new  HashMap<String,Double>();
		locations_weights = this.name_locations_weights.get(query_name);
		return locations_weights;
	}
	
	// enter the branch name and get all read names with their bootstrap support
	public HashMap<String,Double> getNamesWeightsOfLocation(String location){
		HashMap<String,Double> name_weight = new HashMap<String,Double>();
		ArrayList<String> names = this.location_name.get(location);
		for (int i = 0; i< names.size();i++){
			name_weight.put(names.get(i), this.name_locations_weights.get(names.get(i)).get(location));
		}
		return name_weight;
	}
	
	public int getNameInserts(String query_name){
		return this.name_inserts.get(query_name);
	}
	
	public ArrayList<String> getLocations(){
		ArrayList<String> locations = new ArrayList<String>();
		Set<String> keys = location_inserts.keySet(); 
		for (String key : keys){
			locations.add(key);
		}
		return locations;
	}
	
	public HashMap <String,HashMap<String,String>> getLocationAnnotation(){
		return this.location_annotation;
	}
	
	public String setLocationAnnotation(String location,String query, String annotation){
		if (location_annotation.containsKey(location)){
			location_annotation.get(location).put(query ,annotation);
		}	
		return location+" "+query+" "+annotation;
	}
	
	public ArrayList<Double> getValuesForHistogramm(String location){
		return location_weight.get(location);
	}
	
	public Object clone(){
		try {
            return super.clone();
        }
        catch (CloneNotSupportedException e) {
            // This should never happen
            throw new InternalError(e.toString());
        }

	}
	
	public void randomizePlacements(int nodes){
		HashMap <String,HashMap<String,String>> store = new HashMap<String, HashMap<String,String>>();
		Random rnd = new Random();
		ArrayList<ArrayList<String>> new_data = new ArrayList<ArrayList<String>>();
		for (int i = 0; i < this.data.size(); i++){
			int node = 0;
			String location = "I"+node;
			String name = data.get(i).get(0);
			while ((node < 1)|| (store.containsKey(name) && store.get(name).containsKey(location))){
				node = (int)(rnd.nextDouble()*nodes);
				location = "I"+node;
			}
			ArrayList<String> tmp = new ArrayList<String>();
			tmp.add(name); tmp.add(location);tmp.add(this.data.get(i).get(2));
			new_data.add(tmp);
		}
		this.data = new_data;
		collectData();
	}
	
}
