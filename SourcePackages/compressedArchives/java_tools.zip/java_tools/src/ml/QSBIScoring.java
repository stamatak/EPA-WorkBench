package ml;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

public class QSBIScoring {

private int inserts_left = 0;
private int inserts_right = 0;
private HashMap <String,String> left_names = new HashMap<String, String>();
private HashMap <String,String> right_names = new HashMap<String, String>();
private HashMap <String, HashMap<String,Double>> matrix = new HashMap<String, HashMap<String,Double>>();
	private double query_score = 0.0;
	private String query_name = "";

	public QSBIScoring (String query_name) {
		this.query_name = query_name;
	}
	
	public double getQueryScore(){
		return this.query_score;
	}
	
	public double QSBIkNoNormalization(LN left, LN right, ClassificationParser clp){
		collectInserts(left,left.backLabel,clp);
		LN left_copy = LN.deepClone(left);
		LN right_copy = LN.deepClone(right);
		LN[] nodes = {left_copy,right_copy};
		LN root = LN.insertBranch(nodes, 0.0).back;		
		PplacerScoring pp = new PplacerScoring(this.query_name, clp, root);
		convertMatrixToHash(pp.getDistanceMatrix(),pp.getMatrixLabels());
		Set <String> keys = clp.getLocationsWeights(this.query_name).keySet();
		for (String key : keys){
			if (!this.left_names.containsKey(key)&& (!key.equals(left.backLabel))){
				this.right_names.put(key, key);
			}
		}
		Set <String> keys_left = left_names.keySet();
		Set <String> keys_right = right_names.keySet();
		int leftc = keys_left.size();
		int rightc = keys_right.size(); 
		double qsbi = 0.0;
		for (String k1 : keys_left){
			
			HashMap <String,Double> line = this.matrix.get(k1);
			
			for (String k2 : keys_right){
				if (line.containsKey(k2)){
					double w_i = clp.getLocationsWeights(query_name).get(k1);
					double w_j = clp.getLocationsWeights(query_name).get(k2);
					double delta_ij = line.get(k2);
					qsbi = qsbi + delta_ij*(w_i+w_j)*(1-Math.abs(w_i-w_j));
				}	
				else{
					double w_i = clp.getLocationsWeights(query_name).get(k1);
					double w_j = clp.getLocationsWeights(query_name).get(k2);
					double delta_ij = this.matrix.get(k2).get(k1);
					qsbi = qsbi + delta_ij*(w_i+w_j)*(1-Math.abs(w_i-w_j));	
				}
			}
		}
	
		if (qsbi < 0.0 ){
			System.out.println(qsbi+" : ("+leftc+")("+rightc+")");
			System.out.println(qsbi);
		}
		
		return qsbi;
		
	} 
	
	public double QSBIkNoNormalization(LN left, LN right, ClassificationLikelihoodParser clp){
		collectInserts(left,left.backLabel,clp);
		LN left_copy = LN.deepClone(left);
		LN right_copy = LN.deepClone(right);
		LN[] nodes = {left_copy,right_copy};
		LN root = LN.insertBranch(nodes, 0.0).back;		
		PplacerScoring pp = new PplacerScoring(this.query_name, clp, root);
		convertMatrixToHash(pp.getDistanceMatrix(),pp.getMatrixLabels());
		Set <String> keys = clp.getLocationsWeights(this.query_name).keySet();
		
		
		for (String key : keys){
			if (!this.left_names.containsKey(key)&& (!key.equals(left.backLabel))){
				this.right_names.put(key, key);
			}
		}
		Set <String> keys_left = left_names.keySet();
		Set <String> keys_right = right_names.keySet();
		//System.out.println("keys_left: "+keys_left);
		//System.out.println("keys_right: "+keys_right);
//		System.out.println("labels: "+pp.getMatrixLabels());
//		System.out.println("clp: "+clp.getNameLocations(query_name));
//		System.out.println(pp.getDfs());
		int leftc = keys_left.size();
		int rightc = keys_right.size(); 
		double qsbi = 0.0;
		for (String k1 : keys_left){
			
			HashMap <String,Double> line = this.matrix.get(k1);
			
			for (String k2 : keys_right){
				if (line.containsKey(k2)){
					double w_i = clp.getLocationsWeights(query_name).get(k1);
					double w_j = clp.getLocationsWeights(query_name).get(k2);
					double delta_ij = line.get(k2);
					qsbi = qsbi + delta_ij*(w_i+w_j)*(1-Math.abs(w_i-w_j));
				}	
				else{

					double w_i = clp.getLocationsWeights(query_name).get(k1);
					double w_j = clp.getLocationsWeights(query_name).get(k2);
					double delta_ij = this.matrix.get(k2).get(k1);
					qsbi = qsbi + delta_ij*(w_i+w_j)*(1-Math.abs(w_i-w_j));	
				}
			}
		}
		if (qsbi < 0.0 ){
			System.out.println(qsbi+" : ("+leftc+")("+rightc+")");
			System.out.println(qsbi);
		}
		return qsbi;
		
	} 
	
	public void QSBIk(LN left, LN right, ClassificationParser clp){
		collectInserts(left,left.backLabel,clp);
		LN left_copy = LN.deepClone(left);
		LN right_copy = LN.deepClone(right);
		LN[] nodes = {left_copy,right_copy};
		LN root = LN.insertBranch(nodes, 0.0).back;		
		PplacerScoring pp = new PplacerScoring(this.query_name, clp, root);
		convertMatrixToHash(pp.getDistanceMatrix(),pp.getMatrixLabels());
		
		Set <String> keys = clp.getLocationsWeights(this.query_name).keySet();
		for (String key : keys){
			if (!this.left_names.containsKey(key)&& (!key.equals(left.backLabel))){
				this.right_names.put(key, key);
			}
		}
		Set <String> keys_left = left_names.keySet();
		Set <String> keys_right = right_names.keySet();
		int leftc = keys_left.size();
		int rightc = keys_right.size(); 
		double qsbi = 0.0;
		double max_path_b = calculateMaxPath(left,left.backLabel)+calculateMaxPath(right,right.backLabel);
		for (String k1 : keys_left){
			
			HashMap <String,Double> line = this.matrix.get(k1);
			
			for (String k2 : keys_right){
				if (line.containsKey(k2)){
					double w_i = clp.getLocationsWeights(query_name).get(k1);
					double w_j = clp.getLocationsWeights(query_name).get(k2);
					double delta_ij = line.get(k2)/max_path_b;
					qsbi = qsbi + delta_ij*(w_i+w_j)*(1-Math.abs(w_i-w_j));
				}	
				else{
					double w_i = clp.getLocationsWeights(query_name).get(k1);
					double w_j = clp.getLocationsWeights(query_name).get(k2);
					double delta_ij = this.matrix.get(k2).get(k1)/max_path_b;
					qsbi = qsbi + delta_ij*(w_i+w_j)*(1-Math.abs(w_i-w_j));	
				}
			}
		}
		this.query_score = qsbi;
	
		if (this.query_score < 0.0 || this.query_score > 1.0){
			System.out.println(qsbi+" : ("+leftc+")("+rightc+")");
			System.out.println(query_score);
		}

		clp.setLocationAnnotation(left.backLabel, query_name, query_score+"("+rightc+")"+"("+leftc+")"); // LN.next work clockwise, therefore the assignment of LN left and LN right is incorrect and has to be inverted 
	}
	
	public void QSBIk(LN left, LN right, ClassificationLikelihoodParser clp){
		collectInserts(left,left.backLabel,clp);
		LN left_copy = LN.deepClone(left);
		LN right_copy = LN.deepClone(right);
		LN[] nodes = {left_copy,right_copy};
		LN root = LN.insertBranch(nodes, 0.0).back;		
		PplacerScoring pp = new PplacerScoring(this.query_name, clp, root);
		convertMatrixToHash(pp.getDistanceMatrix(),pp.getMatrixLabels());
		
		Set <String> keys = clp.getLocationsWeights(this.query_name).keySet();
		for (String key : keys){
			if (!this.left_names.containsKey(key)&& (!key.equals(left.backLabel))){
				this.right_names.put(key, key);
			}
		}
		Set <String> keys_left = left_names.keySet();
		Set <String> keys_right = right_names.keySet();
		int leftc = keys_left.size();
		int rightc = keys_right.size(); 
		double qsbi = 0.0;
		double max_path_b = calculateMaxPath(left,left.backLabel)+calculateMaxPath(right,right.backLabel);
		for (String k1 : keys_left){
			
			HashMap <String,Double> line = this.matrix.get(k1);
			
			for (String k2 : keys_right){
				if (line.containsKey(k2)){
					double w_i = clp.getLocationsWeights(query_name).get(k1);
					double w_j = clp.getLocationsWeights(query_name).get(k2);
					double delta_ij = (line.get(k2)/max_path_b);
					qsbi = qsbi + delta_ij*(w_i+w_j)*(1-Math.abs(w_i-w_j));
				}	
				else{
					double w_i = clp.getLocationsWeights(query_name).get(k1);
					double w_j = clp.getLocationsWeights(query_name).get(k2);
					double delta_ij =  (this.matrix.get(k2).get(k1)/max_path_b);
					qsbi = qsbi + delta_ij*(w_i+w_j)*(1-Math.abs(w_i-w_j));	
				}
				
			}
		}
		double max_value = leftc*rightc;
		if (max_value < 1.0){
			max_value = 1.0;
		}
		this.query_score = 1.0-qsbi/max_value;
	//	System.out.println(query_score);
	//	System.out.println(left.backLabel+" : "+this.query_score+" : "+max_path_b);
	
		if (this.query_score < 0.0 || this.query_score > 1.0){
			System.out.println(qsbi+" : ("+leftc+")("+rightc+")");
			System.out.println(query_score);
		}
		clp.setLocationAnnotation(left.backLabel, query_name, query_score+"("+rightc+")"+"("+leftc+")"); // LN.next work clockwise, therefore the assignment of LN left and LN right is incorrect and has to be inverted 
		
	}
	
	private void collectInserts(LN root, String ignored_branch,ClassificationParser clp){
		
		if (clp.getLocationsWeights(query_name).containsKey(root.backLabel) && !(root.backLabel.equals(ignored_branch))){
			this.left_names.put(root.backLabel, root.backLabel);
		}
		if (!(root.next.back == null)){
			collectInserts(root.next.back,ignored_branch, clp);
		}
		if (!(root.next.back == null)){
			collectInserts(root.next.next.back, ignored_branch, clp);
		}
		
	}

	private void collectInserts(LN root, String ignored_branch,ClassificationLikelihoodParser clp){
		
		if (clp.getLocationsWeights(query_name).containsKey(root.backLabel) && !(root.backLabel.equals(ignored_branch))){
			this.left_names.put(root.backLabel, root.backLabel);
		}
		if (!(root.next.back == null)){
			collectInserts(root.next.back,ignored_branch, clp);
		}
		if (!(root.next.back == null)){
			collectInserts(root.next.next.back, ignored_branch, clp);
		}
		
	}
	
	private void convertMatrixToHash(ArrayList<ArrayList<Double>> matrix, ArrayList<String> labels){

		for (int i = 0; i < matrix.size(); i++){
			String s = "";
			HashMap<String,Double> tmp = new HashMap<String, Double>();
			for (int j = 0; j< matrix.get(i).size(); j++){
				s = s+" "+labels.get(i+j+1);
				tmp.put(labels.get(i+j+1), matrix.get(i).get(j));
			}
			this.matrix.put(labels.get(i), tmp);
		}
	}
	
	public double calculateMaxPath(LN root,String ignored_branch){
		double length = 0.0;
		if (!root.backLabel.equals(ignored_branch)){
			length = root.backLen;
		}	
		if (!(root.next.back == null)){
			length = length+calculateMaxPath(root.next.back, ignored_branch);
		}
		if (!(root.next.back == null)){
			length = length+calculateMaxPath(root.next.next.back, ignored_branch);
		}
		
		return length;
	}
	
	
	public int getInsertsLeft(){
		return this.inserts_left;
	}
	public int getInsertsRight(){
		return this.inserts_right;
	}
}

