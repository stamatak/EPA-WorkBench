package ml;

import java.util.ArrayList;
import java.util.HashMap;

public class QSBIMScoring {
	
	private HashMap<String,String> left_branches = new HashMap<String,String>();
	private HashMap<String,String> right_branches = new HashMap<String,String>();
	private double query_score = 0.0;
	
	public QSBIMScoring (String query_name,  LN left, LN right ,ClassificationLikelihoodParser clp1, ClassificationLikelihoodParser clp2) {
		determineBranches(left, left_branches, left.backLabel);
		determineBranches(right, right_branches, right.backLabel);
		double positive = calculateScore(query_name, left,  right, clp1, clp2);
		double negative = calculateScore(query_name,  left,  right, clp2, clp1);
		this.query_score = Math.abs(positive - negative);
	}
	
	public QSBIMScoring (String query_name,  LN left, LN right ,ClassificationParser clp1, ClassificationParser clp2) {
		determineBranches(left, left_branches, left.backLabel);
		determineBranches(right, right_branches, right.backLabel);
		double positive = calculateScore(query_name, left,  right, clp1, clp2);
		double negative = calculateScore(query_name,  left,  right, clp2, clp1);
		this.query_score = Math.abs(positive - negative);
	}
	
	private double calculateScore(String query_name, LN left, LN right ,  ClassificationLikelihoodParser clp1, ClassificationLikelihoodParser clp2){
		
		double score = 0.0;
		ArrayList<ArrayList<String>> insert_set = new ArrayList<ArrayList<String>>();
		for (int i = 0; i < clp1.getData().size();i++ ){
			String name1 = clp1.getData().get(i).get(0);
			String location1 = clp1.getData().get(i).get(1);
			if (name1.equals(query_name) && this.left_branches.containsKey(location1)){
				insert_set.add(clp1.getData().get(i));
			}
		}
		for (int i = 0; i < clp2.getData().size();i++ ){
			String name1 = clp2.getData().get(i).get(0);
			String location1 = clp2.getData().get(i).get(1);
			if (name1.equals(query_name) && this.right_branches.containsKey(location1)){
				insert_set.add(clp2.getData().get(i));
			}
		}
		ClassificationLikelihoodParser clp = new ClassificationLikelihoodParser(insert_set);
		QSBIScoring qsbi = new QSBIScoring(query_name);
		qsbi.QSBIk(left, right, clp);
		score = qsbi.getQueryScore();
		return score;
	}
	
private double calculateScore(String query_name, LN left, LN right ,  ClassificationParser clp1, ClassificationParser clp2){
		
		double score = 0.0;
		ArrayList<ArrayList<String>> insert_set = new ArrayList<ArrayList<String>>();
		for (int i = 0; i < clp1.getData().size();i++ ){
			String name1 = clp1.getData().get(i).get(0);
			String location1 = clp1.getData().get(i).get(1);
			if (name1.equals(query_name) && this.left_branches.containsKey(location1)){
				insert_set.add(clp1.getData().get(i));
			}
		}
		for (int i = 0; i < clp2.getData().size();i++ ){
			String name1 = clp2.getData().get(i).get(0);
			String location1 = clp2.getData().get(i).get(1);
			if (name1.equals(query_name) && this.right_branches.containsKey(location1)){
				insert_set.add(clp2.getData().get(i));
			}
		}
		ClassificationLikelihoodParser clp = new ClassificationLikelihoodParser(insert_set);
		QSBIScoring qsbi = new QSBIScoring(query_name);
		qsbi.QSBIk(left, right, clp);
		score = qsbi.getQueryScore();
		return score;
	}
	
	
	public double getQueryScore(){
		return this.query_score;
	}
	
	private void determineBranches(LN root, HashMap<String,String> branches, String first_branch){
		if (!(root.backLabel.equals(first_branch))){
			branches.put(root.backLabel,root.backLabel);
		}
		if (!(root.next.back == null)){
			determineBranches(root.next, branches, first_branch);
		}
		if (!(root.next.back == null)){
			determineBranches(root.next.next, branches, first_branch);
		}
	}
}
