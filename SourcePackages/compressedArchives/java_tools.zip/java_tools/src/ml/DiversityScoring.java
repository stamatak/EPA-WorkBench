package ml;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class DiversityScoring {
	
	private static ArrayList<Double> euler_tour = new ArrayList<Double>();
	private static ArrayList<Integer> levels_euler_tour = new ArrayList<Integer>();
	private static ArrayList<Boolean> marked_euler_tour = new ArrayList<Boolean>();
	private static ArrayList<String> branch_names_euler_tour = new ArrayList<String>();
	
	
	public static void main(String[] args){
		
		String sample1 = "";
		String sample2 = "";
		String treefile = "";
		boolean bootstrapping = false;
		boolean nullmodel = false;
		int bootstrap_samples = 0;
		for(int i = 0; i< args.length; i++){
			if (args[i].equals("-i")){
				i++;
				Pattern p = Pattern.compile("[\\/\\w_\\-\\.]+");
				Matcher m = p.matcher(args[i]);
				if (args[i].equals("-i2") || args[i].equals("-n") || args[i].equals("-t") || args[i].equals("-b")){
					throw new RuntimeException( "Error: file after -i expected, you entered "+args[i]);
				}
				else if (m.matches()){
					sample1 = args[i];
				}
				else {
					throw new RuntimeException( "Error: file after -i expected, you entered "+args[i]);
				}
			}
			else if (args[i].equals("-t")){
				i++;
				Pattern p = Pattern.compile("[\\/\\w_\\-\\.]+");
				Matcher m = p.matcher(args[i]);
				if (args[i].equals("-i2") || args[i].equals("-n") || args[i].equals("-i") || args[i].equals("-b") ){
					throw new RuntimeException( "Error: file after -t expected, you entered "+args[i]);
				}
				else if (m.matches()){
					treefile = args[i];
				}
				else {
					throw new RuntimeException( "Error: file after -t expected, you entered "+args[i]);
				}
			}
			else if (args[i].equals("-i2")){
				i++;
				Pattern p = Pattern.compile("[\\.\\/\\w_\\-]+");
				Matcher m = p.matcher(args[i]);
				if (args[i].equals("-i") || args[i].equals("-n") || args[i].equals("-t") || args[i].equals("-b")){
					throw new RuntimeException( "Error: file after -i2 expected, you entered: "+args[i]);
				}
				else if (m.matches()){
					sample2 = args[i];
				}
				else {
					throw new RuntimeException( "Error: file after -i2 expected, you entered: "+args[i]);
				}
			}
			else if (args[i].equals("-n")){
				nullmodel = true;
			}
			else if (args[i].equals("-b")){
				bootstrapping = true;
				i++;
				Pattern p = Pattern.compile("\\d+");
				Matcher m = p.matcher(args[i]);
				if (args[i].equals("-i2") || args[i].equals("-n") || args[i].equals("-t") || args[i].equals("-i")){
					throw new RuntimeException( "Error: int after -b expected, you entered: "+args[i]);
				}
				else if (m.matches()){
					bootstrap_samples = Integer.parseInt(args[i]);
				}
				else {
					throw new RuntimeException( "Error: int after -b expected, you entered: "+args[i]);
				}
			}
			else {
				throw new RuntimeException( "Error: unknown option: "+args[i]);
			}
		}
		
		if (sample1.equals("") || treefile.equals("")){
			throw new RuntimeException( "Error: can not execute without without sample file or treefile");
		}
		
		if (nullmodel){
			sample2 = buildNullModel(bootstrapping);
		}
	//get root node 
		LN n = TreeParser.parse(new File(treefile));
		LN[][] brs = LN.getBranchList(n);
		int maxs = 0;
		LN[] mb = null;
		for( LN [] br : brs ) {
			String[] ss = LN.getSmallerSplitSet(br);
			int nr = ss.length;
			if( nr > maxs ) {
				maxs = nr;
				mb = br;
			}
		}
		
		LN root = LN.insertBranch(mb, 0.0).back;
		root.backLabel = "root";
		buildEulerTour(root);
		
		
		if (bootstrapping){
			System.out.println("Treefile: "+treefile);
			System.out.println("Unifrac: "+unifrac(new ClassificationParser(new File(sample1),bootstrap_samples), new ClassificationParser(new File(sample2),bootstrap_samples)));
			System.out.println("Phylocom: "+phylocom(new ClassificationParser(new File(sample1),bootstrap_samples), new ClassificationParser(new File(sample2),bootstrap_samples)));
			System.out.println("Comstruct: "+comstruct(new ClassificationParser(new File(sample1),bootstrap_samples), new ClassificationParser(new File(sample2),bootstrap_samples)));
			System.out.println("QSBI: "+qsbi(new ClassificationParser(new File(sample1),bootstrap_samples), new ClassificationParser(new File(sample2),bootstrap_samples)));
		}
		else {
			System.out.println("Treefile: "+treefile);
			System.out.println("Classfile1: "+sample1);
			System.out.println("Classfile2: "+sample2);
			System.out.println("Unifrac: "+unifrac(new ClassificationLikelihoodParser(new File(sample1)), new ClassificationLikelihoodParser(new File(sample2))));
			System.out.println("Phylocom: "+phylocom(new ClassificationLikelihoodParser(new File(sample1)), new ClassificationLikelihoodParser(new File(sample2))));
			System.out.println("Comstruct: "+comstruct(new ClassificationLikelihoodParser(new File(sample1)), new ClassificationLikelihoodParser(new File(sample2))));
			System.out.println("QSBI: "+qsbi(new ClassificationLikelihoodParser(new File(sample1)), new ClassificationLikelihoodParser(new File(sample2))));
		}
	}

// Nullmodell
	
	public static String buildNullModel(boolean bootstrapping){
		String classificationfile = "";
		
		return classificationfile;
	}
	
	
// Diversity Measures
	// ClassificationLikelihood
	
	//UNFICRAC//
	public static double unifrac(ClassificationLikelihoodParser sample1, ClassificationLikelihoodParser sample2 ){
		double diversity = 0.0;
		double u = 0.0;
		double d = 0.0;
		double[] sum_euler_tour = new double[euler_tour.size()];
		sum_euler_tour[0] = euler_tour.get(0);
		
		for (int i = 1; i< euler_tour.size(); i++){
			sum_euler_tour[i] = sum_euler_tour[i-1]+euler_tour.get(i);
		}
		ArrayList<Boolean> marked_sample1 = markPath(branch_names_euler_tour, sample1.getLocations());
		ArrayList<Boolean> marked_sample2 = markPath(branch_names_euler_tour, sample2.getLocations());
		double a_T = sample1.getLocations().size();
		double b_T = sample2.getLocations().size();
		double a_t = sample1.getLocationName().size();
		double b_t = sample2.getLocationName().size();
		HashMap <String,String> keys = getKeySet(sample1.getLocations(),sample2.getLocations());
		for (int i = 0; i< euler_tour.size(); i++){
			u = u+euler_tour.get(i)*Math.abs(descendants(sample1,marked_sample1, i)/a_T - descendants(sample2,marked_sample2,i)/b_T);
			if (keys.containsKey(branch_names_euler_tour.get(i))){
				double a_i = sample1.getLocationConfidence().get(branch_names_euler_tour.get(i));
				double b_i = sample2.getLocationConfidence().get(branch_names_euler_tour.get(i));
				d = d+(sum_euler_tour[i]*(a_i/a_t+b_i/b_t));
			}
		}
		diversity = u/d; 
		return diversity;
	}
	
	private static double descendants(ClassificationLikelihoodParser sample, ArrayList<Boolean> marked, int index){
		double descendants = 0.0;
		int current_level = levels_euler_tour.get(index);
		for (int i = 0; i < marked.size();i++){
			if (marked.get(i) && current_level <= levels_euler_tour.get(i)){
				double confidence = sample.getLocationConfidence().get(branch_names_euler_tour.get(i));
 				descendants = descendants+1.0;// *confidence; definition of unifrac without weights
			}
			else if (current_level <= levels_euler_tour.get(i)){
				break;
			}
		}
		
		return descendants;
	}
	
	private static HashMap<String,String> getKeySet(ArrayList<String> sample1,ArrayList<String> sample2){
		HashMap <String,String> keys = new HashMap<String,String>();
		for (int i = 0; i< sample1.size(); i++){
			for (int j = 0; j< sample2.size(); j++){
				if (sample1.get(i).equals(sample2.get(j))){
					keys.put(sample2.get(j),sample2.get(j));
					sample2.remove(j);
					break;
				}
			}
		}
		return keys;
	}
	//PHYLOCOM//
	public static double phylocom(ClassificationLikelihoodParser sample1, ClassificationLikelihoodParser sample2){
		double diversity = 0.0;
		double[] sum_euler_tour = new double[euler_tour.size()];
		sum_euler_tour[0] = euler_tour.get(0);
		
		for (int i = 1; i< euler_tour.size(); i++){
			sum_euler_tour[i] = sum_euler_tour[i-1]+euler_tour.get(i);
		}
		
		ClassificationLikelihoodParser[] samples = {sample1,sample2};
		for (int k = 0; k< samples.length; k++){
			int i = 0;
			int counter = 0;
			double div = 0.0;
			markPath(branch_names_euler_tour, samples[k].getLocations());
			for (int j = 0; j< sum_euler_tour.length; j++){
				if (marked_euler_tour.get(j)){
					marked_euler_tour.set(j, false);
					double branch_confidence = samples[k].getLocationConfidence().get(marked_branches_sequence.get(counter));
					double half_branch_length = marked_branches_lengths.get(marked_branches_sequence.get(counter));
					div  = div + (sum_euler_tour[j]-calculateRMQ(i,j,sum_euler_tour)-half_branch_length);//*branch_confidence;
					
					counter  = counter+1;
					i = j;
				}
			}
			System.out.println(div);
			diversity = Math.abs(diversity - div);
		}
		
		return diversity;
	}
	
	//COMSTRUCT//  needs Null Model
	public static double comstruct(ClassificationLikelihoodParser sample1, ClassificationLikelihoodParser sample2){
		double diversity = 0.0;
		
		return diversity;
	}
	
	//QSBI//
	public static double qsbi(ClassificationLikelihoodParser sample1, ClassificationLikelihoodParser sample2){
		double diversity = 0.0;
		
		return diversity;
	}
		
	//BOOTSTRAP
	public static double unifrac(ClassificationParser sample1, ClassificationParser sample2 ){
		double diversity = 0.0;
		
		return diversity;
	}
	
	public static double phylocom(ClassificationParser sample1, ClassificationParser sample2){
		double diversity = 0.0;
		
		return diversity;
	}
	
	public static double comstruct(ClassificationParser sample1, ClassificationParser sample2){
		double diversity = 0.0;
		
		return diversity;
	}
	
	public static double qsbi(ClassificationParser sample1, ClassificationParser sample2){
		double diversity = 0.0;
		
		return diversity;
	}
	
//Helper Functions & Variables
	
	private static ArrayList<Double> dfs = new ArrayList<Double>();
	private static ArrayList<Integer> levels = new ArrayList<Integer>();
	private static ArrayList<String> branch_name_path = new ArrayList<String>();
	private static ArrayList<String> marked_branches_sequence = new ArrayList<String>();
	private static HashMap<String,Double> marked_branches_lengths = new HashMap<String,Double>();
	
	public static Object[] buildEulerTour(LN root){

	    ArrayList<Double> node_path = new ArrayList<Double>();
	    Object[] results = new Object[3];
		
		pathToArray(root, 0);
				
		int max_level = getMaxLevel(levels);
		double[] higher_nodes = new double[max_level+1];
		euler_tour.add(dfs.get(0));
		levels_euler_tour.add(levels.get(0));
		node_path.add(dfs.get(0));
		higher_nodes[0] = dfs.get(0);
		branch_names_euler_tour.add(branch_name_path.get(0));
		
		for (int i = 1; i< dfs.size();i++){
			if (levels.get(i) - levels.get(i-1) == 1){
				euler_tour.add(dfs.get(i));
				levels_euler_tour.add(levels.get(i));
				node_path.add(dfs.get(i));
				branch_names_euler_tour.add(branch_name_path.get(i));
			}
			else if (levels.get(i-1)- levels.get(i) >= 0){
				int jump_to = levels.get(i)-1;
				for (int j = levels.get(i-1) ;j > jump_to; j--){
					euler_tour.add(0.0-higher_nodes[j]);
					levels_euler_tour.add(j-1);
					node_path.add(higher_nodes[j-1]);
					branch_names_euler_tour.add(branch_name_path.get(j-1));
				}
				euler_tour.add(dfs.get(i));
				levels_euler_tour.add(levels.get(i));
				node_path.add(dfs.get(i));
				branch_names_euler_tour.add(branch_name_path.get(i));
			}
			else {
				System.out.println("ERROR: "+levels.get(i-1).toString()+" => "+ levels.get(i).toString());
			}

			higher_nodes[levels.get(i)] =  dfs.get(i);
		}
		results[0] = euler_tour;
		results[1] = levels_euler_tour ;
		results[2] = marked_euler_tour;
		return results;
	}
	
	private static void pathToArray(LN root, int level){
		dfs.add(root.backLen);
		levels.add(level);
		branch_name_path.add(root.backLabel);
		if (!(root.next.back == null)){
			pathToArray(root.next.back, level+1);
		}
		if (!(root.next.next.back == null)){
			pathToArray(root.next.next.back, level+1);
		}
	}
	
	private static ArrayList <Boolean> markPath(ArrayList<String> path, ArrayList<String> names_to_be_marked){
		marked_euler_tour.clear();
		marked_branches_sequence.clear();
		marked_branches_lengths.clear();
		
		for (int i = 0; i< path.size(); i++){
			boolean add = false;
			for (int j = 0; j < names_to_be_marked.size(); j++){
				if (path.get(i).equals(names_to_be_marked.get(j))){
					names_to_be_marked.remove(j);
					add = true;
					break;
				}			
			}	
			if (add){
				marked_branches_sequence.add(path.get(i));
				marked_branches_lengths.put(path.get(i), Math.abs(euler_tour.get(i))/2.0);
				marked_euler_tour.add(add);
			}
			else
			{
				marked_euler_tour.add(add);
			}
		}
		return marked_euler_tour;
	}
	private static int getMaxLevel(ArrayList<Integer> levels){
		int max = 0;
		for (int i = 0; i< levels.size();i++){
			if (max < levels.get(i)){
				max = levels.get(i);
			}
		}
		return max;
	}
	
	public static double calculateRMQ(int i, int j, double[] sum_euler_tour){

		double rmq = 1000000000.0;
		for (int k = i; k<=j; k++){
			if (sum_euler_tour[k] < rmq){
				rmq = sum_euler_tour[k];
			}
		}
	
		if (rmq < 0.0){
			rmq = 0.0;   // due to floating point arithmetics, the path back over the root might be negative
		}
		return rmq;
		
	}
	
	
	
	
}
