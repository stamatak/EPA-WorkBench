package ml;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;

public class ExtractTreeTaxa {
	
	public static void main(String[] args){
		File treefile = new File(args[0]);
		String outfile  = args[1]; 
		try{
			LN t = TreeParser.parse(treefile);
			Set<String> ts = LN.getTipSet(LN.getAsList(t));
			writeToFile(ts,outfile);
			System.out.printf( "good\n" );
		}
		catch(RuntimeException e ) {
			e.printStackTrace();
		}
		
	}

	public static void writeToFile(Set<String> lines, String file){
	    try{
	        // Create file 
	        FileWriter fstream = new FileWriter(file);
	        BufferedWriter out = new BufferedWriter(fstream);
	        Iterator<String> iter = lines.iterator();
	        while (iter.hasNext()){
	        	out.write(iter.next()+"\n");
	        }
	        //Close the output stream
	        out.close();
	    }
	    catch (Exception e){//Catch exception if any
	    	e.printStackTrace();
	    }
	}
	
}
