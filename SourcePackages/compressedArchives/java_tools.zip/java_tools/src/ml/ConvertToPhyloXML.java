package ml;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ConvertToPhyloXML {
	
//	private static HashMap<String,Double> edplBranchScores = new HashMap<String, Double>();
	private static HashMap<String,Double> bipartitionBranchScores = new HashMap<String, Double>();
	
	public static void main(String[] args) {
		
		String treefile = args[0];
		String classfile = args[1];
		boolean use_bootstrap = false;
		int bootstrap_samples = 0;
		if (args.length > 2){
			use_bootstrap = true;
			bootstrap_samples = Integer.valueOf(args[2]);
		}
			
		
		// insert root node
		LN n = TreeParser.parse(new File(treefile));
		LN[][] brs = LN.getBranchList(n);		
		int maxs = 0;
		LN[] mb = null;
		for( LN [] br : brs ) {
			String[] ss = LN.getSmallerSplitSet(br);
			int nr = ss.length;
			if( nr > maxs ) {
				maxs = nr;
				mb = br;
			}
		}
		LN left_copy = LN.deepClone(mb[0]);
		LN right_copy = LN.deepClone(mb[1]);
		LN[] nodes = {left_copy,right_copy};
		LN root = insertBranch(nodes, 0.0).back;
		root.backLabel = "IROOT";
		root.next.backLabel = left_copy.backLabel;
		root.next.next.backLabel = right_copy.backLabel+"a";
		right_copy.backLabel = right_copy.backLabel+"a";
		String version = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
		String header = "<phyloxml xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.phyloxml.org http://www.phyloxml.org/1.10/phyloxml.xsd\" xmlns=\"http://www.phyloxml.org\">\n";
		if (use_bootstrap){
			ClassificationParser clp = new ClassificationParser(new File(classfile),bootstrap_samples);
			calcultateEDPLConfidences( root,clp);
			bipartitionBranchScores = calculateBipartitionConfidence(root, clp);
			System.out.println(version+header+"<phylogeny rooted=\"true\">\n<clade branch_length = \""+String.valueOf(left_copy.backLen)+ "\">");
			buildPhyloXML(left_copy,right_copy,1,clp);
			System.out.println("</clade></phylogeny></phyloxml>");
		}
		else{
			ClassificationLikelihoodParser clp = new ClassificationLikelihoodParser(new File(classfile));
			calcultateEDPLConfidences( root,clp);
			bipartitionBranchScores = calculateBipartitionConfidence(root, clp);
			System.out.println(version+header+"<phylogeny rooted=\"true\">\n<clade branch_length = \""+String.valueOf(left_copy.backLen)+ "\">");
			buildPhyloXML(left_copy,right_copy,1,clp);
			System.out.println("</clade></phylogeny></phyloxml>");
		}
	}
	
	public static void buildPhyloXML(LN left, LN right, int level,ClassificationLikelihoodParser clp){
		
		double location_confidence_left = bipartitionBranchScores.get(left.backLabel);
		double location_confidence_right = bipartitionBranchScores.get(right.backLabel);
		// Leaves are not scored, for this reason they are set to 0
		if (new Double(location_confidence_left).isNaN()){
			location_confidence_left = 0.0;
		}
		if (new Double(location_confidence_right).isNaN()){
			location_confidence_right = 0.0;
		}
		String shift = "";
		
		//def width tag
		String width_left = "";
		String width_right = "";
		if (clp.getLocationBranchThickness().get(left.backLabel)!= null){
			width_left= shift+"<width>"+clp.getLocationBranchThickness().get(left.backLabel)+"</width>\n";
		}
		if (clp.getLocationBranchThickness().get(right.backLabel)!= null){
			width_right= shift+"<width>"+clp.getLocationBranchThickness().get(right.backLabel)+"</width>\n";
		}
		
		//def name tag
		String name_left = "";
		String name_right = "";
		
		if (left.data.isTip){
			name_left = shift+"<name>"+left.data.getTipName()+"</name>\n";
		}
		if (right.data.isTip){
			name_right = shift+"<name>"+right.data.getTipName()+"</name>\n";
		}
		
		//def color tag
		String color_left = "";
		String color_right ="";
		color_left =  getXMLColor(location_confidence_left,shift);
		color_right =  getXMLColor(location_confidence_right,shift);
		
		//def taxonomy tag
		StringBuilder tax_left = new StringBuilder(4096);
		StringBuilder tax_right =new StringBuilder(4096);
		if  (!(clp.getLocationName().get(left.backLabel) != null)){
			//used to get the amount of inserts to the branches with no inserts for calculating the node size later
			tax_left.append("<sequence>\n");
			tax_left.append("<name>");
			tax_left.append(left.backLabel);
			tax_left.append("</name>\n");
			tax_left.append("<annotation><desc>");
			tax_left.append(clp.getHighestAmountOfInserts());
			tax_left.append(",</desc></annotation>\n");
			tax_left.append("</sequence>\n");
		}
		if  (!(clp.getLocationConfidence().get(right.backLabel) != null)){
			//used to get the amount of inserts to the branches with no inserts for calculating the node size later
			tax_right.append("<sequence>\n");
			tax_right.append("<name>");
			tax_right.append(left.backLabel);
			tax_right.append("</name>\n");
			tax_right.append("<annotation><desc>");
			tax_right.append(clp.getHighestAmountOfInserts());
			tax_right.append(",</desc></annotation>\n");
			tax_right.append("</sequence>\n");
		}
		
		if (left.next.back != null){
			StringBuilder sb = new StringBuilder(4096);
			sb.append("<clade branch_length = \"");
			sb.append(String.valueOf(left.backLen));
			sb.append("\">\n");
			sb.append(name_left);
			sb.append(width_left);
			sb.append(color_left);
			System.out.println(sb.toString());
			if  (clp.getLocationName().get(left.backLabel) != null){
				dataToPhyloXML(clp.getLocationAnnotation().get(left.backLabel),clp.getValuesForHistogramm(left.backLabel),clp.getNamesWeightsOfLocation(left.backLabel),left.backLabel,shift,clp.getHighestAmountOfInserts(),location_confidence_left);
			}
			else{
				//used to get the amount of inserts to the branches with no inserts for calculating the node size later
				System.out.print("<sequence>\n");
				System.out.print("<name>");
				System.out.print(left.backLabel);
				System.out.print("</name>\n");
				System.out.print("<annotation><desc>");
				System.out.print(clp.getHighestAmountOfInserts());
				System.out.print(",</desc></annotation>\n");
				System.out.print("</sequence>\n");
				System.out.print("<sequence>\n");
				System.out.print("<name>");
				System.out.print(left.backLabel);
				System.out.print("</name>\n");
				System.out.print("<annotation><confidence type=\"qsbi\">");
				System.out.print(location_confidence_left);
				System.out.print("</confidence></annotation>\n");
				System.out.print("</sequence>\n");
			}
			
			buildPhyloXML(left.next.back, left.next.next.back, level+1, clp);
			System.out.println("</clade>");
		}
		else{
			StringBuilder sb = new StringBuilder(4096);
			sb.append("<clade branch_length = \"");
			sb.append(String.valueOf(left.backLen));
			sb.append("\">\n");
			sb.append(name_left);
			sb.append(width_left);
			sb.append(color_left);
			System.out.println(sb.toString());
			if  (clp.getLocationName().get(left.backLabel) != null){
				dataToPhyloXML(clp.getLocationAnnotation().get(left.backLabel),clp.getValuesForHistogramm(left.backLabel),clp.getNamesWeightsOfLocation(left.backLabel),left.backLabel,shift,clp.getHighestAmountOfInserts(),location_confidence_left);
			}
			else{
				//used to get the amount of inserts to the branches with no inserts for calculating the node size later
				System.out.print("<sequence>\n");
				System.out.print("<name>");
				System.out.print(left.backLabel);
				System.out.print("</name>\n");
				System.out.print("<annotation><desc>");
				System.out.print(clp.getHighestAmountOfInserts());
				System.out.print(",</desc></annotation>\n");
				System.out.print("</sequence>\n");
				System.out.print("<sequence>\n");
				System.out.print("<name>");
				System.out.print(left.backLabel);
				System.out.print("</name>\n");
				System.out.print("<annotation><confidence type=\"qsbi\">");
				System.out.print(location_confidence_left);
				System.out.print("</confidence></annotation>\n");
				System.out.print("</sequence>\n");
			}
			System.out.println("</clade>");
			
		}
		if (right.next.back != null){
			StringBuilder sb = new StringBuilder(4096);
			sb.append("<clade branch_length = \"");
			sb.append(String.valueOf(right.backLen));
			sb.append("\">\n");
			sb.append(name_right);
			sb.append(width_right);
			sb.append(color_right);
			System.out.println(sb.toString());
			if  (clp.getLocationName().get(right.backLabel) != null){
				dataToPhyloXML(clp.getLocationAnnotation().get(right.backLabel),clp.getValuesForHistogramm(right.backLabel),clp.getNamesWeightsOfLocation(right.backLabel),right.backLabel,shift,clp.getHighestAmountOfInserts(),location_confidence_right);
			}
			else{
				//used to get the amount of inserts to the branches with no inserts for calculating the node size later
				System.out.print("<sequence>\n");
				System.out.print("<name>");
				System.out.print(right.backLabel);
				System.out.print("</name>\n");
				System.out.print("<annotation><desc>");
				System.out.print(clp.getHighestAmountOfInserts());
				System.out.print(",</desc></annotation>\n");
				System.out.print("</sequence>\n");
				System.out.print("<sequence>\n");
				System.out.print("<name>");
				System.out.print(right.backLabel);
				System.out.print("</name>\n");
				System.out.print("<annotation><confidence type=\"qsbi\">");
				System.out.print(location_confidence_right);
				System.out.print("</confidence></annotation>\n");
				System.out.print("</sequence>\n");
			}
			buildPhyloXML(right.next.back, right.next.next.back, level+1, clp);
			System.out.println("</clade>");
		}
		else{
			StringBuilder sb = new StringBuilder(4096);
			sb.append("<clade branch_length = \"");
			sb.append(String.valueOf(right.backLen));
			sb.append("\">\n");
			sb.append(name_right);
			sb.append(width_right);
			sb.append(color_right);
			System.out.println(sb.toString());
			if  (clp.getLocationName().get(right.backLabel) != null){
				dataToPhyloXML(clp.getLocationAnnotation().get(right.backLabel),clp.getValuesForHistogramm(right.backLabel),clp.getNamesWeightsOfLocation(right.backLabel),right.backLabel,shift,clp.getHighestAmountOfInserts(),location_confidence_right);
			}
			else{
				//used to get the amount of inserts to the branches with no inserts for calculating the node size later
				System.out.print("<sequence>\n");
				System.out.print("<name>");
				System.out.print(right.backLabel);
				System.out.print("</name>\n");
				System.out.print("<annotation><desc>");
				System.out.print(clp.getHighestAmountOfInserts());
				System.out.print(",</desc></annotation>\n");
				System.out.print("</sequence>\n");
				System.out.print("<sequence>\n");
				System.out.print("<name>");
				System.out.print(right.backLabel);
				System.out.print("</name>\n");
				System.out.print("<annotation><confidence type=\"qsbi\">");
				System.out.print(location_confidence_right);
				System.out.print("</confidence></annotation>\n");
				System.out.print("</sequence>\n");
			}
			System.out.println("</clade>");
		}
	}
	
	public static void buildPhyloXML(LN left, LN right, int level,ClassificationParser clp){
		double location_confidence_left = bipartitionBranchScores.get(left.backLabel);
		double location_confidence_right = bipartitionBranchScores.get(right.backLabel);
		String shift = "";
		// Leaves are not scored, for this reason they are set to 0
		if (new Double(location_confidence_left).isNaN()){
			location_confidence_left = 0.0;
		}
		if (new Double(location_confidence_right).isNaN()){
			location_confidence_right = 0.0;
		}
		//def width tag
		String width_left = "";
		String width_right = "";
		if (clp.getLocationBranchThickness().get(left.backLabel)!= null){
			width_left= shift+"<width>"+clp.getLocationBranchThickness().get(left.backLabel)+"</width>\n";
		}
		if (clp.getLocationBranchThickness().get(right.backLabel)!= null){
			width_right= shift+"<width>"+clp.getLocationBranchThickness().get(right.backLabel)+"</width>\n";
		}
		
		//def name tag
		String name_left = "";
		String name_right = "";
		
		if (left.data.isTip){
			name_left = shift+"<name>"+left.data.getTipName()+"</name>\n";
		}
		if (right.data.isTip){
			name_right = shift+"<name>"+right.data.getTipName()+"</name>\n";
		}
		
		//def color tag
		String color_left = "";
		String color_right ="";
		color_left =  getXMLColor(location_confidence_left,shift);
		color_right =  getXMLColor(location_confidence_right,shift);
		
		//def taxonomy tag
		StringBuilder tax_left = new StringBuilder(4096);
		StringBuilder tax_right =new StringBuilder(4096);
		if  (!(clp.getLocationName().get(left.backLabel) != null)){
			//used to get the amount of inserts to the branches with no inserts for calculating the node size later
			tax_left.append("<sequence>\n");
			tax_left.append("<name>");
			tax_left.append(left.backLabel);
			tax_left.append("</name>\n");
			tax_left.append("<annotation><desc>");
			tax_left.append(clp.getHighestAmountOfInserts());
			tax_left.append(",</desc></annotation>\n");
			tax_left.append("</sequence>\n");
		}
		if  (!(clp.getLocationConfidence().get(right.backLabel) != null)){
			//used to get the amount of inserts to the branches with no inserts for calculating the node size later
			tax_right.append("<sequence>\n");
			tax_right.append("<name>");
			tax_right.append(left.backLabel);
			tax_right.append("</name>\n");
			tax_right.append("<annotation><desc>");
			tax_right.append(clp.getHighestAmountOfInserts());
			tax_right.append(",</desc></annotation>\n");
			tax_right.append("</sequence>\n");
		}
		
		if (left.next.back != null){
			StringBuilder sb = new StringBuilder(4096);
			sb.append("<clade branch_length = \"");
			sb.append(String.valueOf(left.backLen));
			sb.append("\">\n");
			sb.append(name_left);
			sb.append(width_left);
			sb.append(color_left);
			System.out.println(sb.toString());
			if  (clp.getLocationName().get(left.backLabel) != null){
				dataToPhyloXML(clp.getLocationAnnotation().get(left.backLabel),clp.getValuesForHistogramm(left.backLabel),clp.getNamesWeightsOfLocation(left.backLabel),left.backLabel,shift,clp.getHighestAmountOfInserts(),location_confidence_left);
			}
			else{
				//used to get the amount of inserts to the branches with no inserts for calculating the node size later
				System.out.print("<sequence>\n");
				System.out.print("<name>");
				System.out.print(left.backLabel);
				System.out.print("</name>\n");
				System.out.print("<annotation><desc>");
				System.out.print(clp.getHighestAmountOfInserts());
				System.out.print(",</desc></annotation>\n");
				System.out.print("</sequence>\n");
				System.out.print("<sequence>\n");
				System.out.print("<name>");
				System.out.print(left.backLabel);
				System.out.print("</name>\n");
				System.out.print("<annotation><confidence type=\"qsbi\">");
				System.out.print(location_confidence_left);
				System.out.print("</confidence></annotation>\n");
				System.out.print("</sequence>\n");
			}
			
			buildPhyloXML(left.next.back, left.next.next.back, level+1, clp);
			System.out.println("</clade>");
		}
		else{
			StringBuilder sb = new StringBuilder(4096);
			sb.append("<clade branch_length = \"");
			sb.append(String.valueOf(left.backLen));
			sb.append("\">\n");
			sb.append(name_left);
			sb.append(width_left);
			sb.append(color_left);
			System.out.println(sb.toString());
			if  (clp.getLocationName().get(left.backLabel) != null){
				dataToPhyloXML(clp.getLocationAnnotation().get(left.backLabel),clp.getValuesForHistogramm(left.backLabel),clp.getNamesWeightsOfLocation(left.backLabel),left.backLabel,shift,clp.getHighestAmountOfInserts(),location_confidence_left);
			}
			else{
				//used to get the amount of inserts to the branches with no inserts for calculating the node size later
				System.out.print("<sequence>\n");
				System.out.print("<name>");
				System.out.print(left.backLabel);
				System.out.print("</name>\n");
				System.out.print("<annotation><desc>");
				System.out.print(clp.getHighestAmountOfInserts());
				System.out.print(",</desc></annotation>\n");
				System.out.print("</sequence>\n");
				System.out.print("<sequence>\n");
				System.out.print("<name>");
				System.out.print(left.backLabel);
				System.out.print("</name>\n");
				System.out.print("<annotation><confidence type=\"qsbi\">");
				System.out.print(location_confidence_left);
				System.out.print("</confidence></annotation>\n");
				System.out.print("</sequence>\n");
			}
			System.out.println("</clade>");
			
		}
		if (right.next.back != null){
			StringBuilder sb = new StringBuilder(4096);
			sb.append("<clade branch_length = \"");
			sb.append(String.valueOf(right.backLen));
			sb.append("\">\n");
			sb.append(name_right);
			sb.append(width_right);
			sb.append(color_right);
			System.out.println(sb.toString());
			if  (clp.getLocationName().get(right.backLabel) != null){
				dataToPhyloXML(clp.getLocationAnnotation().get(right.backLabel),clp.getValuesForHistogramm(right.backLabel),clp.getNamesWeightsOfLocation(right.backLabel),right.backLabel,shift,clp.getHighestAmountOfInserts(),location_confidence_right);
			}
			else{
				//used to get the amount of inserts to the branches with no inserts for calculating the node size later
				System.out.print("<sequence>\n");
				System.out.print("<name>");
				System.out.print(right.backLabel);
				System.out.print("</name>\n");
				System.out.print("<annotation><desc>");
				System.out.print(clp.getHighestAmountOfInserts());
				System.out.print(",</desc></annotation>\n");
				System.out.print("</sequence>\n");
				System.out.print("<sequence>\n");
				System.out.print("<name>");
				System.out.print(right.backLabel);
				System.out.print("</name>\n");
				System.out.print("<annotation><confidence type=\"qsbi\">");
				System.out.print(location_confidence_right);
				System.out.print("</confidence></annotation>\n");
				System.out.print("</sequence>\n");
			}
			buildPhyloXML(right.next.back, right.next.next.back, level+1, clp);
			System.out.println("</clade>");
		}
		else{
			StringBuilder sb = new StringBuilder(4096);
			sb.append("<clade branch_length = \"");
			sb.append(String.valueOf(right.backLen));
			sb.append("\">\n");
			sb.append(name_right);
			sb.append(width_right);
			sb.append(color_right);
			System.out.println(sb.toString());
			if  (clp.getLocationName().get(right.backLabel) != null){
				dataToPhyloXML(clp.getLocationAnnotation().get(right.backLabel),clp.getValuesForHistogramm(right.backLabel),clp.getNamesWeightsOfLocation(right.backLabel),right.backLabel,shift,clp.getHighestAmountOfInserts(),location_confidence_right);
			}
			else{
				//used to get the amount of inserts to the branches with no inserts for calculating the node size later
				System.out.print("<sequence>\n");
				System.out.print("<name>");
				System.out.print(right.backLabel);
				System.out.print("</name>\n");
				System.out.print("<annotation><desc>");
				System.out.print(clp.getHighestAmountOfInserts());
				System.out.print(",</desc></annotation>\n");
				System.out.print("</sequence>\n");
				System.out.print("<sequence>\n");
				System.out.print("<name>");
				System.out.print(right.backLabel);
				System.out.print("</name>\n");
				System.out.print("<annotation><confidence type=\"qsbi\">");
				System.out.print(location_confidence_right);
				System.out.print("</confidence></annotation>\n");
				System.out.print("</sequence>\n");
			}
			System.out.println("</clade>");
		}
	}
		
	private static String getXMLColor(double confidence, String shift){
		if (confidence < 0.0){
			System.out.println(confidence);
			System.exit(0);
		}
		String shift2 = shift+" ";
		double cutoff = 0.0;
		double m = 255.0 / (1.0 - cutoff);
		double b = m - 255;
		int blue = 0;
		int red = 255;
		Double val = m*(confidence) - b ;
		int green = val.intValue();
		red = red-green;
		if (red > 255){
			System.out.println(red);
			System.out.println(confidence);
			System.out.println(b);
			System.out.println(m);
			System.exit(0);
		}
		String color = shift+"<color>\n"+shift2+"<red>"+red+"</red>\n"+shift2+"<green>"+green+"</green>\n"+shift2+"<blue>"+blue+"</blue>\n"+shift+"</color>\n";
		return color;
	}
	
	private static void dataToPhyloXML(HashMap <String,String> names, ArrayList<Double> histogram_values, HashMap<String,Double> name_weights, String branch_name , String shift, int amount_of_inserts, double qsbi){
 		
		
		// Histogram
		String histogram = "";
		String inserts = String.valueOf(amount_of_inserts)+",";
		int[] bins = fillBins(histogram_values);
		String[] new_bins = nicerRepresentationWithASCIIBars(bins);
		for (int i = 0; i < new_bins.length; i++){
			if (i < 9) {
				histogram = histogram+"0."+i+" - 0."+(i+1)+": "+new_bins[i]+",";
			}
			else
			{	
				histogram = histogram+"0."+i+" - 1.0: "+new_bins[i]+",";	
			}
		}
		//first sequence object with histogram
		StringBuilder phyloxml =   new StringBuilder(4096*4);
		phyloxml.append("<sequence>\n");
		phyloxml.append("<name>");
		phyloxml.append(branch_name);
		phyloxml.append("</name>\n");
		phyloxml.append("<annotation><desc>");
		phyloxml.append(inserts);
		phyloxml.append(histogram);
		phyloxml.append("</desc></annotation>\n");
		phyloxml.append("</sequence>\n");
		
		
		// inserts with EDPL confidences and RAxML weights
		Set<String> keys = names.keySet();
		for (String key : keys){
			String insert_name = key;
			String edpl_score = names.get(key);
			String raxml_weight = name_weights.get(key).toString();
			
			phyloxml.append("<sequence>\n");
			phyloxml.append("<name>");
			phyloxml.append(insert_name);
			phyloxml.append("</name>\n");
			phyloxml.append("<annotation><confidence type=\"edpl\">");
			phyloxml.append(edpl_score);
			phyloxml.append("</confidence></annotation>\n");
			phyloxml.append("<annotation><confidence type=\"raxml_weight\">");
			phyloxml.append(raxml_weight);
			phyloxml.append("</confidence></annotation>\n");
			phyloxml.append("<annotation><confidence type=\"qsbi\">");
			phyloxml.append(qsbi);
			phyloxml.append("</confidence></annotation>\n");
			phyloxml.append("</sequence>\n");
		}
		System.out.print(phyloxml);
	}
	
	
	
	// SCORINGS **QSBI & EDPL**
	
	private static HashMap<String,Double> calculateBipartitionConfidence(	LN root, ClassificationLikelihoodParser clp	){
		
		return new BipartitionScoreWeighted(root, clp).getLocationConfidence();
	}
	
	private static HashMap<String,Double> calculateBipartitionConfidence(	LN root, ClassificationParser clp	){
		
		return new BipartitionScoreWeighted(root, clp).getLocationConfidence();
	}
	
	private static HashMap<String,Double> calcultateEDPLConfidences( LN root, ClassificationLikelihoodParser clp){
		
		HashMap <String,Double> confs = new HashMap<String, Double>();
		HashMap <String,Double> location_confidence = new HashMap<String, Double>();
		EDPLScoring edpl = new EDPLScoring(root);
		Set <String> keys = clp.getNames().keySet();
		
		// calculate EDPL for each query sequence (key)
		for (String key : keys){
			confs.put(key, (double)edpl.calculateScore(key, clp));
		}
		keys = clp.getLocationName().keySet();
		
		// calculate mean EDPL for every branch (key) that has placements
		for (String key : keys){
			location_confidence.put(key, (calculateBranchConfidence(clp.getLocationName().get(key), confs )/(clp.getLocationInserts().get(key).doubleValue())));
			
			// round the EDPL score for every query sequence (name) 
			for (int n = 0; n<clp.getLocationName().get(key).size();n++){
				String name = clp.getLocationName().get(key).get(n);
				Double c = confs.get(name);
				String conf = "";
				int digits_behind_zero = 0;
				if (c != 0.0){
					for (int i = 0; c < 1.0 ; i++ ){
						c = c*10.0;
						digits_behind_zero = digits_behind_zero+1;
					}
					if (digits_behind_zero > 3){
						c = (Double.valueOf(c.intValue()) / (Double.valueOf(Math.pow(10.0,digits_behind_zero))) );
						conf = c.toString();
					}
					else{
						conf = confs.get(name).toString();
						if (conf.length()>5){
							conf = conf.substring(0, 5);
						}	
					}
				}
				else {
					conf = c.toString();
				}
				
				clp.setLocationAnnotation(key, name, conf);
			}
		}
		return location_confidence;
	}
	
	private static double calculateBranchConfidence(ArrayList<String> placements_on_a_certain_location, HashMap<String,Double> confidences){ // formular 3
		double conf = 0.0;
		for (int i = 0; i< placements_on_a_certain_location.size();i++){
			conf = conf+confidences.get(placements_on_a_certain_location.get(i));
		}
		return conf;
	}
	
	private static HashMap<String,Double> calcultateEDPLConfidences( LN root, ClassificationParser clp){
		
		HashMap <String,Double> confs = new HashMap<String, Double>();
		HashMap <String,Double> location_confidence = new HashMap<String, Double>();
		EDPLScoring edpl = new EDPLScoring(root);
		Set <String> keys = clp.getNames().keySet();
		
		// calculate EDPL for each query sequence (key)
		for (String key : keys){
			confs.put(key, (double)edpl.calculateScore(key, clp));
		}
		keys = clp.getLocationName().keySet();
		
		// calculate mean EDPL for every branch (key) that has placements
		for (String key : keys){
			location_confidence.put(key, (calculateBranchConfidence(clp.getLocationName().get(key), confs )/(clp.getLocationInserts().get(key).doubleValue())));
			
			// round the EDPL score for every query sequence (name) 
			for (int n = 0; n<clp.getLocationName().get(key).size();n++){
				String name = clp.getLocationName().get(key).get(n);
				Double c = confs.get(name);
				String conf = "";
				int digits_behind_zero = 0;
				if (c != 0.0){
					for (int i = 0; c < 1.0 ; i++ ){
						c = c*10.0;
						digits_behind_zero = digits_behind_zero+1;
					}
					if (digits_behind_zero > 3){
						c = (Double.valueOf(c.intValue()) / (Double.valueOf(Math.pow(10.0,digits_behind_zero))) );
						conf = c.toString();
					}
					else{
						conf = confs.get(name).toString();
						if (conf.length()>5){
							conf = conf.substring(0, 5);
						}	
					}
				}
				else {
					conf = c.toString();
				}
				
				clp.setLocationAnnotation(key, name, conf);
			}
		}
		return location_confidence;
	}
	
	// HELPER METHODS
	
	private static int[] fillBins(ArrayList<Double> values){
		
		int[] bins = new int[10];
		for (int i =0; i < bins.length; i++){
			bins[i] = 0;
		}
		
		for (int i =0; i < values.size(); i++){
			int bin = (int)(values.get(i)*10.0); // 0.1 stepwise bin
			if (bin >= 10){
				bin = 9;
			}
			bins[bin]++;
		}
		return bins;
		
	}
	
	private static String[] nicerRepresentationWithASCIIBars(int[] bins){
		String[] s = new String[bins.length];
		int inserts = 0;
		for (int i = 0; i < bins.length; i++){
			inserts = inserts+bins[i];
		}
		double div = ((double)inserts)/10.0;
		for (int i = 0; i < bins.length; i++){
			s[i] = amountOfBars(div,bins[i])+" "+bins[i];
		}
		return s;
	}
	
	private static String amountOfBars(double div, int bin){
		String s = "";
		double max = ((double)bin)/div;
		int c = 0;
		for (int i = 0; i< max ; i++){
			s = s+"|";
			c ++;
		}
		for (int i = 0; i< 10-c ; i++){
			s = s+".";
		}
		return s;
	}
	
	public static LN insertBranch(LN[] br, double len) {
		LN nl = LN.create();
		
		double bl = br[0].backLen;
		
		br[0].back = nl.next;
		nl.next.back = br[0];
		br[0].backLen = nl.next.backLen = bl;
		 
		br[1].back = nl.next.next;
		nl.next.next.back = br[1];
		br[1].backLen = nl.next.next.backLen = 0.0;
		
		LN nt = LN.create();
		
		nt.back = nl;
		nl.back = nt;
		
		nt.backLen = nl.backLen = len;
		
		return nt;
	}
}
