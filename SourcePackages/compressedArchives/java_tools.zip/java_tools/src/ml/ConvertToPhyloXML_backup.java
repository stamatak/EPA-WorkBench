package ml;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ConvertToPhyloXML_backup {
	
	private static HashMap<String,Double> pplacerBranchScores = new HashMap<String, Double>();
	private static HashMap<String,Double> query_sequence_significance = new HashMap<String, Double>();
	private static int tree_size = 0;
	
	private static boolean test = false;
	private static int fold = 0;
	
	private static boolean use_second_classfile = false;
	private static String classfile2 = "";
	
	public static void main(String[] args) {
		
		String treefile = "";
		String classfile1 = "";
		boolean use_bootstrap1 = false;
		int bootstrap1 = 0;
		boolean use_bootstrap2 = false;
		int bootstrap2 = 0;
		
		for(int i = 0; i< args.length; i++){
			if (args[i].equals("-t")){
				i++;
				Pattern p = Pattern.compile("[\\/\\w_\\-\\.]+");
				Matcher m = p.matcher(args[i]);
				if (args[i].equals("-c") || args[i].equals("-c2") || args[i].equals("-b") || args[i].equals("-test")){
					throw new RuntimeException( "Error: file after -t expected, you entered "+args[i]);
				}
				else if (m.matches()){
					treefile = args[i];
				}
				else {
					throw new RuntimeException( "Error: file after -t expected, you entered "+args[i]);
				}
			}
			else if (args[i].equals("-c")){
				i++;
				Pattern p = Pattern.compile("[\\/\\w_\\-\\.]+");
				Matcher m = p.matcher(args[i]);
				if (args[i].equals("-t") || args[i].equals("-c2") || args[i].equals("-test") || args[i].equals("-b") ){
					throw new RuntimeException( "Error: file after -c expected, you entered "+args[i]);
				}
				else if (m.matches()){
					classfile1 = args[i];
				}
				else {
					throw new RuntimeException( "Error: file after -c expected, you entered "+args[i]);
				}
			}
			else if (args[i].equals("-c2")){
				i++;
				Pattern p = Pattern.compile("[\\.\\/\\w_\\-]+");
				Matcher m = p.matcher(args[i]);
				if (args[i].equals("-c") || args[i].equals("-t") || args[i].equals("-test") || args[i].equals("-b")){
					throw new RuntimeException( "Error: file after -c2 expected, you entered: "+args[i]);
				}
				else if (m.matches()){
					classfile2 = args[i];
					use_second_classfile = true;
				}
				else {
					throw new RuntimeException( "Error: file after -i2 expected, you entered: "+args[i]);
				}
			}
			else if (args[i].equals("-test")){
				i++;
				Pattern p = Pattern.compile("\\d+");
				Matcher m = p.matcher(args[i]);
				if (args[i].equals("-c") || args[i].equals("-t") || args[i].equals("-c2") || args[i].equals("-b")){
					throw new RuntimeException( "Error: file after -test expected, you entered: "+args[i]);
				}
				else if (m.matches()){
					fold = Integer.parseInt(args[i]);
					test = true;
				}
				else {
					throw new RuntimeException( "Error: file after -test expected, you entered: "+args[i]);
				}
				
			}
			else if (args[i].equals("-b")){
				i++;
				Pattern p = Pattern.compile("\\d+");
				Matcher m = p.matcher(args[i]);
				if (args[i].equals("-c") || args[i].equals("-c2") || args[i].equals("-t") || args[i].equals("-test")){
					throw new RuntimeException( "Error: int after -b expected, you entered: "+args[i]);
				}
				else if (m.matches()){
					bootstrap1 = Integer.parseInt(args[i]);
					use_bootstrap1 = true;
				}
				else {
					throw new RuntimeException( "Error: int after -b expected, you entered: "+args[i]);
				}
			}
			else if (args[i].equals("-b2")){
				i++;
				Pattern p = Pattern.compile("\\d+");
				Matcher m = p.matcher(args[i]);
				if (args[i].equals("-c") || args[i].equals("-c2") || args[i].equals("-t") || args[i].equals("-test")){
					throw new RuntimeException( "Error: int after -b expected, you entered: "+args[i]);
				}
				else if (m.matches()){
					bootstrap2 = Integer.parseInt(args[i]);
					use_bootstrap2 = true;
				}
				else {
					throw new RuntimeException( "Error: int after -b expected, you entered: "+args[i]);
				}
			}
			else {
				throw new RuntimeException( "Error: unknown option: "+args[i]);
			}
		}
		
		
		LN n = TreeParser.parse(new File(treefile));
		LN[][] brs = LN.getBranchList(n);
		
		int maxs = 0;
		LN[] mb = null;
		for( LN [] br : brs ) {
			String[] ss = LN.getSmallerSplitSet(br);
			int nr = ss.length;
			if( nr > maxs ) {
				maxs = nr;
				mb = br;
			}
		}

		LN left_copy = LN.deepClone(mb[0]);
		LN right_copy = LN.deepClone(mb[1]);
		tree_size = LN.getAsList(left_copy).length;
		String version = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
		String header = "<phyloxml xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.phyloxml.org http://www.phyloxml.org/1.10/phyloxml.xsd\" xmlns=\"http://www.phyloxml.org\">\n";
		String phyloXML="";
		if (use_bootstrap1){
			ClassificationParser clp1 = new ClassificationParser(new File(classfile1),bootstrap1);
			pplacerBranchScores = calcultatePPlacerConfidences( left_copy,  right_copy,clp1);
			phyloXML = version+header+"<phylogeny rooted=\"true\">\n<clade branch_length = \""+String.valueOf(mb[0].backLen)+ "\">\n"+buildPhyloXML(mb[0],mb[1],1,clp1)+"</clade></phylogeny></phyloxml>";
		}
		else{
			ClassificationLikelihoodParser clp1 = new ClassificationLikelihoodParser(new File(classfile1));
			pplacerBranchScores = calcultatePPlacerConfidences( left_copy,  right_copy,clp1);	
			phyloXML = version+header+"<phylogeny rooted=\"true\">\n<clade branch_length = \""+String.valueOf(mb[0].backLen)+ "\">\n"+buildPhyloXML(mb[0],mb[1],1,clp1)+"</clade></phylogeny></phyloxml>";			
		}
		Set <String> keys = query_sequence_significance.keySet();
		for (String key : keys){
			
			System.out.println(key+": "+query_sequence_significance.get(key));
		}
		
	//System.out.printf(phyloXML);
	}
	
	public static String buildPhyloXML(LN left, LN right, int level,ClassificationLikelihoodParser clp){
		if (test){
			permutationTest( left, left.back, clp,fold);
			permutationTest(right, right.back, clp, fold);
		}
		double location_confidence_left= 0.0;
		double location_confidence_right = 0.0;
		if (use_second_classfile){
			ClassificationLikelihoodParser clp2 = new ClassificationLikelihoodParser(new File(classfile2));
			location_confidence_left = calculateQSBIMConfidence(left,left.back,clp, clp2);
			location_confidence_right = calculateQSBIMConfidence(right,right.back,clp, clp2);
		}
		else{
			location_confidence_left = calculateQSBIConfidence(left,left.back,clp);
			location_confidence_right  = calculateQSBIConfidence(right,right.back,clp);
			//		double location_confidence_left = getPplacerBranchconfidence(left.backLabel);
			//		double location_confidence_right = getPplacerBranchconfidence(right.backLabel);
		}
		String shift = "";
		for (int i = 0 ; i <= level; i++){
			shift = shift+" ";
		}
		
		//def width tag
		String width_left = "";
		String width_right = "";
		if (clp.getLocationBranchThickness().get(left.backLabel)!= null){
			width_left= shift+"<width>"+clp.getLocationBranchThickness().get(left.backLabel)+"</width>\n";
		}
		if (clp.getLocationBranchThickness().get(right.backLabel)!= null){
			width_right= shift+"<width>"+clp.getLocationBranchThickness().get(right.backLabel)+"</width>\n";
		}
		
		//def name tag
		String name_left = "";
		String name_right = "";
		
		if (left.data.isTip){
			name_left = shift+"<name>"+left.data.getTipName()+"</name>\n";
		}
		if (right.data.isTip){
			name_right = shift+"<name>"+right.data.getTipName()+"</name>\n";
		}
		
		//def color tag
		String color_left = "";
		String color_right ="";
	//	if  (clp.getLocationName().get(left.backLabel) != null){
			color_left =  getXMLColor(location_confidence_left,shift);
	//	}
	//	if  (clp.getLocationName().get(right.backLabel) != null){
			color_right =  getXMLColor(location_confidence_right,shift);
	//	}
		
		//def taxonomy tag
		String tax_left ="";
		String tax_right ="";
		if  (clp.getLocationName().get(left.backLabel) != null){
			tax_left =  shift+"<sequence>\n"+shift+" "+listNames(clp.getLocationAnnotation().get(left.backLabel))+shift+"</sequence>\n";
		}
		if  (clp.getLocationConfidence().get(right.backLabel) != null){
			tax_right =  shift+"<sequence>\n"+shift+" "+listNames(clp.getLocationAnnotation().get(right.backLabel))+shift+"</sequence>\n";
		}
		
		String leftside = "";
		String rightside = "";
		if (!(left.next.back == null)){
			leftside =shift+"<clade branch_length = \""+String.valueOf(left.backLen)+"\">\n"+name_left+width_left+color_left+tax_left+buildPhyloXML(left.next.back, left.next.next.back, level+1, clp)+shift+"</clade>\n";
		}
		else{
			leftside = shift+"<clade branch_length = \""+String.valueOf(left.backLen)+ "\">\n"+name_left+width_left+color_left+tax_left+shift+"</clade>\n";
		}
		if (!(right.next.back == null)){
			rightside = shift+"<clade branch_length = \""+String.valueOf(right.backLen)+"\">\n"+name_right+width_right+color_right+tax_right+buildPhyloXML(right.next.back, right.next.next.back,level+1,clp)+shift+"</clade>\n";
		}
		else{
			rightside = shift+"<clade branch_length = \""+String.valueOf(right.backLen)+"\">\n"+name_right+width_right+color_right+tax_right+shift+"</clade>\n";
		}
		
		return leftside+rightside;
	}
	
	public static String buildPhyloXML(LN left, LN right, int level,ClassificationParser clp){
		if (test){
			permutationTest( left, left.back, clp,fold);
			permutationTest(right, right.back, clp, fold);
		}
		double location_confidence_left = calculateQSBIConfidence(left,left.back,clp);
		double location_confidence_right  = calculateQSBIConfidence(right,right.back,clp);
//		double location_confidence_left = getPplacerBranchconfidence(left.backLabel);
//		double location_confidence_right = getPplacerBranchconfidence(right.backLabel);
		String shift = "";
		for (int i = 0 ; i <= level; i++){
			shift = shift+" ";
		}
		
		//def width tag
		String width_left = "";
		String width_right = "";
		if (clp.getLocationBranchThickness().get(left.backLabel)!= null){
			width_left= shift+"<width>"+clp.getLocationBranchThickness().get(left.backLabel)+"</width>\n";
		}
		if (clp.getLocationBranchThickness().get(right.backLabel)!= null){
			width_right= shift+"<width>"+clp.getLocationBranchThickness().get(right.backLabel)+"</width>\n";
		}
		
		//def name tag
		String name_left = "";
		String name_right = "";
		
		if (left.data.isTip){
			name_left = shift+"<name>"+left.data.getTipName()+"</name>\n";
		}
		if (right.data.isTip){
			name_right = shift+"<name>"+right.data.getTipName()+"</name>\n";
		}
		
		//def color tag
		String color_left = "";
		String color_right ="";
		if  (clp.getLocationName().get(left.backLabel) != null){
			color_left =  getXMLColor(location_confidence_left,shift);
		}
		if  (clp.getLocationName().get(right.backLabel) != null){
			color_right =  getXMLColor(location_confidence_right,shift);
		}
		
		//def taxonomy tag
		String tax_left ="";
		String tax_right ="";
		if  (clp.getLocationName().get(left.backLabel) != null){
			tax_left =  shift+"<sequence>\n"+shift+" "+listNames(clp.getLocationAnnotation().get(left.backLabel))+shift+"</sequence>\n";
		}
		if  (clp.getLocationConfidence().get(right.backLabel) != null){
			tax_right =  shift+"<sequence>\n"+shift+" "+listNames(clp.getLocationAnnotation().get(right.backLabel))+shift+"</sequence>\n";
		}
		
		String leftside = "";
		String rightside = "";
		if (!(left.next.back == null)){
			leftside =shift+"<clade branch_length = \""+String.valueOf(left.backLen)+"\">\n"+name_left+width_left+color_left+tax_left+buildPhyloXML(left.next.back, left.next.next.back, level+1, clp)+shift+"</clade>\n";
		}
		else{
			leftside = shift+"<clade branch_length = \""+String.valueOf(left.backLen)+ "\">\n"+name_left+width_left+color_left+tax_left+shift+"</clade>\n";
		}
		if (!(right.next.back == null)){
			rightside = shift+"<clade branch_length = \""+String.valueOf(right.backLen)+"\">\n"+name_right+width_right+color_right+tax_right+buildPhyloXML(right.next.back, right.next.next.back,level+1,clp)+shift+"</clade>\n";
		}
		else{
			rightside = shift+"<clade branch_length = \""+String.valueOf(right.backLen)+"\">\n"+name_right+width_right+color_right+tax_right+shift+"</clade>\n";
		}
		
		return leftside+rightside;
	}
	
	private static String getXMLColor(double confidence, String shift){
		String shift2 = shift+" ";
		int blue = 0;
		int red = 255;
		Double val = (confidence*255.0);
		int green = val.intValue();
		red = red-green;
		String color = shift+"<color>\n"+shift2+"<red>"+red+"</red>\n"+shift2+"<green>"+green+"</green>\n"+shift2+"<blue>"+blue+"</blue>\n"+shift+"</color>\n";
		return color;
	}
	
	private static String listNames(HashMap <String,String> names){
		String list ="<annotation><desc>";
		Set<String> keys = names.keySet();
		int i = 0;
		for (String key : keys){
			if (i == names.size()-1) {
				list = list+key+": "+names.get(key);
			}
			else{
				list = list+key+": "+names.get(key)+",";
			}
			i = i+1;
		}
		return list+"</desc></annotation>\n";
	}
	
	private static HashMap<String,Double> calcultatePPlacerConfidences( LN left,  LN right, ClassificationLikelihoodParser clp){
		LN[] nodes = {left,right};
		LN root = LN.insertBranch(nodes, 0.0).back;
		
		HashMap <String,Double> confs = new HashMap<String, Double>();
		HashMap <String,Double> location_confidence = new HashMap<String, Double>();
		Set <String> keys = clp.getNames().keySet();
		for (String key : keys){
			confs.put(key, new PplacerScoring(key, clp,root).getQueryScore());
		}
		keys = clp.getLocationName().keySet();
		for (String key : keys){
			location_confidence.put(key, (calculateBranchConfidence(clp.getLocationName().get(key), confs )/clp.getLocationInserts().get(key).doubleValue()));
		}
		return location_confidence;
	}
	private static double calculateBranchConfidence(Set<String> queries, HashMap<String,Double> confidences){ // formular 3
		double conf = 0.0;
		for (String key : queries){
			conf = conf+confidences.get(key)/queries.size();
		}
		return conf;
	}
	private static double calculateBranchConfidence(ArrayList<String> inserts, HashMap<String,Double> confidences){ // formular 3
		double conf = 0.0;
		for (int i = 0; i< inserts.size();i++){
			conf = conf+confidences.get(inserts.get(i));
		}
		return conf;
	}
	
	private static HashMap<String,Double> calcultatePPlacerConfidences( LN left,  LN right, ClassificationParser clp){
	
		LN[] nodes = {left,right};
		LN root = LN.insertBranch(nodes, 0.0).back;
		
		HashMap <String,Double> confs = new HashMap<String, Double>();
		HashMap <String,Double> location_confidence = new HashMap<String, Double>();
		Set <String> keys = clp.getNames().keySet();
		for (String key : keys){
			confs.put(key, new PplacerScoring(key, clp,root).getQueryScore());
		}
		keys = clp.getLocationName().keySet();
		for (String key : keys){
			location_confidence.put(key, (calculateBranchConfidence(clp.getLocationName().get(key), confs )/clp.getLocationInserts().get(key).doubleValue()));
		}
		return location_confidence;
	}
	
	private static double getPplacerBranchconfidence(String branch_label){
		if (pplacerBranchScores.containsKey(branch_label)){
			return pplacerBranchScores.get(branch_label);
		}
		return 0.0;
	}
	
	private static double calculateQSBIConfidence( LN left,  LN right, ClassificationLikelihoodParser clp){
		
		HashMap <String,Double> confs = new HashMap<String, Double>();
		double local_confidence  = 0.0; 
		String current_location = left.backLabel;
		Set<String> keys = clp.getNames().keySet();
		for(String key : keys){
			QSBIScoring qsbi = new QSBIScoring(key);
			qsbi.QSBIk(left, right, clp);
			confs.put(key, qsbi.getQueryScore());
		}
		
		local_confidence= calculateBranchConfidence(keys, confs );
		return local_confidence;
		}
		
	
	
	private static double calculateQSBIConfidence( LN left,  LN right, ClassificationParser clp){

		HashMap <String,Double> confs = new HashMap<String, Double>();
		double local_confidence  = 0.0; 
		String current_location = left.backLabel;
		Set <String> keys = clp.getNames().keySet();
		for(String key : keys){
			QSBIScoring qsbi = new QSBIScoring(key);
			qsbi.QSBIk(left, right, clp);
			confs.put(key, qsbi.getQueryScore());
		}

		local_confidence= calculateBranchConfidence(keys, confs );
		return local_confidence;
		}
	private static void permutationTest(LN left, LN right, ClassificationLikelihoodParser clp, int fold){
		//System.out.println(left.backLabel);
		Set <String> keys = clp.getNames().keySet();
		ArrayList <String> k = new ArrayList<String>();
		double result = 0.0;
		for (String key : keys){   // ??? java.util.ConcurrentModificationException ???
			k.add(key);
			if (!query_sequence_significance.containsKey(key)){
				query_sequence_significance.put(key, 0.0);
			}
			
			//PermutationTest pt = new PermutationTest(key, clp,left,right,fold); 
			
		}
		for (int i = 0; i <k.size();i++){
			String key = k.get(i);
			if (clp.getNameLocations(key).size() > 1){
				PermutationTest pt = new PermutationTest(key, clp,left,right,fold);
				double current_score = query_sequence_significance.get(key);
				query_sequence_significance.put(key, current_score+(pt.getResult()/ (double)tree_size)); 
			}
			else {
				query_sequence_significance.put(key, 1.0); 
			}
		}
		
		//System.out.println(result / (double)fold);
	}
	
	private static void permutationTest(LN left, LN right, ClassificationParser clp, int fold){
		//System.out.println(left.backLabel);
		Set <String> keys = clp.getNames().keySet();
		ArrayList <String> k = new ArrayList<String>();
		double result = 0.0;
		for (String key : keys){   // ??? java.util.ConcurrentModificationException ???
			k.add(key);
			if (!query_sequence_significance.containsKey(key)){
				query_sequence_significance.put(key, 0.0);
			}
			
			//PermutationTest pt = new PermutationTest(key, clp,left,right,fold); 
			
		}
		for (int i = 0; i <k.size();i++){
			String key = k.get(i);
			if (clp.getNameLocations(key).size() > 1){
				PermutationTest pt = new PermutationTest(key, clp,left,right,fold);
				double current_score = query_sequence_significance.get(key);
				query_sequence_significance.put(key, current_score+(pt.getResult()/ (double)tree_size)); 
			}
			else {
				query_sequence_significance.put(key, 1.0); 
			}
		}
		
		//System.out.println(result / (double)fold);
	}
	private static double calculateQSBIMConfidence( LN left,  LN right, ClassificationLikelihoodParser clp1, ClassificationLikelihoodParser clp2){

		HashMap <String,Double> confs = new HashMap<String, Double>();
		double local_confidence  = 0.0; 
		String current_location = left.backLabel;
		Set <String> keys = clp1.getNames().keySet();
		for(String key : keys){
			QSBIMScoring qsbi = new QSBIMScoring(key,left,right,clp1,clp2);
			confs.put(key, qsbi.getQueryScore());
		}

		local_confidence= calculateBranchConfidence(keys, confs );
		return local_confidence;
		}
	
	
	
}
