package ml;

public class PermutationTest {
	
	private double result = 0.0;
	
	public PermutationTest (String query_name, ClassificationParser clp, LN left, LN right, int fold) {
		
	}
		
	public PermutationTest (String query_name, ClassificationLikelihoodParser clp, LN left, LN right, int fold) {
		if (clp.getNameLocations(query_name).size() > 1){
			int nodes = LN.getAsList(left).length;
			double d_b_ref = new QSBIScoring(query_name).QSBIkNoNormalization(left, right, clp);
			ClassificationLikelihoodParser rnd = (ClassificationLikelihoodParser)clp.clone();
			int counter = 0;
			for (int i = 0; i < fold; i++){
				rnd.randomizePlacements(nodes);
				double d_b_rnd = new QSBIScoring(query_name).QSBIkNoNormalization(left, right, rnd);
		
				if (d_b_ref >= d_b_rnd){
					counter++;
				}
			}
			this.result = 1.0-((double) counter) / ((double) fold);
		}
		else
		{
			this.result = 1.0;
		}
	}
	
	public double getResult(){
		return this.result;
	}
	
}
