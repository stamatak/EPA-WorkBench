package ml;

import java.io.File;



public class FindMidBranch {
	public static void main(String[] args) {
		LN n = TreeParser.parse(new File( args[0]) );
		
		LN[][] brs = LN.getBranchList(n);
		
		
		int maxs = 0;
		LN[] mb = null;
		for( LN [] br : brs ) {
			String[] ss = LN.getSmallerSplitSet(br);
			int nr = ss.length;
			if( nr > maxs ) {
				maxs = nr;
				mb = br;
			}
		}
		String[] ss = LN.getSmallerSplitSet(mb);
		
		for( String s : ss ) {
			System.out.printf( "%s ", s );
		}
		System.out.println( mb[0].backLabel );
	}
}
