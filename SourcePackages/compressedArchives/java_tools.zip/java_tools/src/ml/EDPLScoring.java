package ml;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Set;

public class EDPLScoring {
	
	private ArrayList<Double> marked_nodes_half_branch_length = new ArrayList<Double>(); 
	private ArrayList<String> names = new ArrayList<String>();
	
	private ArrayList<ArrayList<Double>> distance_matrix = new ArrayList<ArrayList<Double>>();
	private ArrayList<String> query_locations = new  ArrayList<String>();
	private HashMap <String,Double> locations_weights = new HashMap <String,Double>();
	private ArrayList<String> marked_branches_sequence = new ArrayList<String>();
	private HashMap<String,Double> marked_branches_lengths = new HashMap<String,Double>();
	
	
	private double query_score = 0.0;
	private String query_name = "";
	private double shortest_path = 0.0;
	private double average_path = 0.0;
	private double all_branch_sum = 0.0;
	private int leaves = 0;
	private int count = 0;
	
	private ArrayList<String> dfs_pathway = new ArrayList<String>();
	private ArrayList<String> euler_pathway = new ArrayList<String>();
	private ArrayList<Float> euler_node_path = new ArrayList<Float>();
	private ArrayList<String> euler_node_pathway = new ArrayList<String>();
	private ArrayList<Float> euler_tour = new ArrayList<Float>();
	private ArrayList<Integer> levels_euler_tour = new ArrayList<Integer>();
	private ArrayList<Boolean> marked_euler_tour = new ArrayList<Boolean>();
	private ArrayList<Float> node_path_euler_tour = new ArrayList<Float>();
	private ArrayList<Boolean> marked_leaves_euler_tour = new ArrayList<Boolean>();
	
	
	private float[][] branch_matrix;
	private HashMap<String,Float> half_branch_length = new HashMap<String, Float>();
	private ArrayList<Float> first_row = new ArrayList<Float>();  
	private HashMap<String,Integer> backLabel_index = new HashMap<String, Integer>();  // holds the index of the first occurrence of a branch Label within the tree
	private HashMap<String,Integer> backLabel_index_euler_tour = new HashMap<String, Integer>(); 
	private float longest_path = 1.0f;
	private float total_tree_length= 1.0f;
	private ArrayList<Boolean> lca_is_marked = new ArrayList<Boolean>();
	private ArrayList<Float> rmqs_sums = new ArrayList<Float>();
	private ArrayList<Float> rmqs = new ArrayList<Float>();
	private ArrayList<String> rmqs_names = new ArrayList<String>();
	private ArrayList<String> branch_names = new ArrayList<String>();
	
	public EDPLScoring (LN root) {
		pathToArray( root, 0, 0.0f);
		//initialize for mark euler_tour
		for(int i = 0; i < euler_pathway.size(); i++){
			if (backLabel_index_euler_tour.get(euler_pathway.get(i)) == null){
				backLabel_index_euler_tour.put(euler_pathway.get(i), i);
			}
		}
		initialize_matrix();
		getLongestAverageAndShortestPath();
	}
	
	private void pathToArray(LN root, int level, float sum){
		total_tree_length += root.backLen;
		sum	 = sum+(float)(root.backLen);
		branch_names.add(root.backLabel);
		first_row.add(sum);
//		if (first_row.size() > 1){
//			backLabel_index.put(root.backLabel,first_row.size()-2); // first_row.size -2 is the index of backLabel in the matrix
//		}
		backLabel_index.put(root.backLabel,first_row.size()-1);
		half_branch_length.put(root.backLabel,(float)(root.backLen / 2.0));
		euler_tour.add((float)(root.backLen));
		levels_euler_tour.add(level);
		
		node_path_euler_tour.add((float)root.backLen);
		dfs_pathway.add(root.backLabel);
		
		euler_pathway.add(root.backLabel);
		euler_node_path.add((float)root.backLen);
		euler_node_pathway.add(root.backLabel);
		marked_euler_tour.add(false);
		
		
		if (root.next.back == null || root.next.next.back == null){
			marked_leaves_euler_tour.add(true);
			leaves++;
		}
		else{
			marked_leaves_euler_tour.add(false);
		}
		if (!(root.next.back == null)){
			pathToArray(root.next.back, level+1,sum);
			euler_tour.add(0.0f - (float)root.next.backLen);
			node_path_euler_tour.add((float)root.next.backLen);
			levels_euler_tour.add(level);
			marked_euler_tour.add(false); // dont mark twice
			euler_pathway.add(root.next.backLabel);
			marked_leaves_euler_tour.add(false);
			euler_node_path.add((float)root.backLen); // for getting the right values for the rmq array later (root.backLen is no mistake here)
			euler_node_pathway.add(root.backLabel);
		}
		
		if (!(root.next.next.back == null)){
			pathToArray(root.next.next.back, level+1,sum);
			euler_tour.add(0.0f - (float)root.next.next.backLen);
			node_path_euler_tour.add((float)root.next.next.backLen);
			levels_euler_tour.add(level);
			marked_euler_tour.add(false); // dont mark twice
			euler_pathway.add(root.next.next.backLabel);
			marked_leaves_euler_tour.add(false);
			euler_node_path.add((float)root.backLen); // for getting the right values for the rmq array later
			euler_node_pathway.add(root.backLabel);
		}	
	}

	private void initialize_matrix(){
		String s = "";
		
		branch_matrix = new float[backLabel_index.size()-1][];
		for ( int i = 0; i < backLabel_index.size()-1   ; i++){
			branch_matrix[i] = new float[backLabel_index.size()-i-1];
			for (int j = 0; j < branch_matrix[i].length; j++ ){
				branch_matrix[i][j] = -1.0f;
			}
		}
		for(int i = 0; i < branch_matrix[0].length; i++){ // i=1 because the first value is the distance from the root to itself
			branch_matrix[0][i] = first_row.get(i+1);
			s = s+i+" => "+branch_matrix[0][i]+"; ";
			
		}
//		System.out.println(s);
//		System.out.println(hToS(backLabel_index));
//		System.out.println(aToS(first_row));
	}
	
	private String aToS(ArrayList a ){
		String s = "";
		for (int i = 0; i < a.size(); i++){
			s = s+i+" => "+a.get(i).toString()+"; ";
		}
		
		return s;
	}
	
	private String hToS(HashMap<String,Integer> h){
		String s = "";
		Set <String> keys = h.keySet();
		for (String key : keys){
			s = s+key+" => "+h.get(key).toString()+"; ";
		}
		return s;
	}
	
	private String bToS(float[] a ){
		String s = "";
		for (int i = 0; i < a.length; i++){
			s = s+i+" => "+a[i]+"; ";
		}
		
		return s;
	}
	
	
	public float calculateScore(String name, ClassificationLikelihoodParser clp){
		query_name = name;
		query_locations = clp.getNameLocations(query_name);
		query_locations = sortByOccurrenceInTheTree(query_locations);
		float score = 0.0f;	
		HashMap <String,Double> branch_weights = clp.getLocationsWeights(query_name);
		ArrayList <String> branches_with_placements = query_locations;
		if (branches_with_placements.size() > 1){
			calculateRMQs();  // build the range minimum queries for the lca requests
			for(int i=0; i < branches_with_placements.size()-1; i++){
				int i2 = getIndexI(branches_with_placements.get(i));
				for (int j = i+1; j < branches_with_placements.size(); j++ ){
					int j2 = getIndexJ(branches_with_placements.get(j),i2);
					float value = 0.0f;
					// if score is already  present in the matrix, then take it
					if (branch_matrix[i2][j2] > 0.0f){
						value = branch_matrix[i2][j2];
					}
					// else calculate score and write it into the matrix
					else {
						
						float lca = calculateLCA(i,j);
//						if (query_name.equals("GIJMJ8F04EPGBN_4_P1M+N-E1c")){
//							System.out.println(aToS(query_locations));
//							System.out.println(aToS(lca_is_marked));
//							System.out.println(aToS(rmqs_sums));
//							System.out.println(aToS(rmqs_names));
//							System.out.println(aToS(euler_pathway));
//							System.out.println(aToS(euler_node_pathway));
//							calculateLCAWithPrint(i, j);
//						}
						
						if (lca < 0.0f){ // one of the marked nodes is the lca, then lca = -1.0
							branch_matrix[i2][j2] = Math.abs((branch_matrix[0][i2-1]-half_branch_length.get(branches_with_placements.get(i))) - (branch_matrix[0][backLabel_index.get(branches_with_placements.get(j))-1] - half_branch_length.get(branches_with_placements.get(j))));
							if (branch_matrix[i2][j2]<0.0){
								System.out.println();
								System.out.println("-lca-"+query_name+";"+branches_with_placements.get(i)+"-----");
								System.out.println(branch_matrix[0][i2-1]);
								System.out.println(half_branch_length.get(branches_with_placements.get(i)));
								System.out.println(branch_matrix[0][backLabel_index.get(branches_with_placements.get(j))-1]);
								System.out.println(half_branch_length.get(branches_with_placements.get(j)));
								System.out.println("----------------");
								System.exit(0);
							}
						}
						else{
							
							branch_matrix[i2][j2] = branch_matrix[0][i2-1] - half_branch_length.get(branches_with_placements.get(i))+ branch_matrix[0][backLabel_index.get(branches_with_placements.get(j))-1] - half_branch_length.get(branches_with_placements.get(j))- 2*lca;
							if (branch_matrix[i2][j2]<0.0 ){
								System.out.println();
//								System.out.println("j2: "+j2);
//								System.out.println("j: "+ backLabel_index.get(branches_with_placements.get(j)) );
//								System.out.println("i2: "+i2);
//								System.out.println("i: "+ backLabel_index.get(branches_with_placements.get(i)) );
//								System.out.println(bToS(branch_matrix[i2]));
								System.out.println("-----"+query_name+";"+branches_with_placements.get(i)+";"+branches_with_placements.get(j)+"-----");
								System.out.println("S: "+branch_matrix[i2][j2]);
								System.out.println("RA: "+branch_matrix[0][i2-1]);
								System.out.println("hA: "+half_branch_length.get(branches_with_placements.get(i)));
								System.out.println("RB: "+branch_matrix[0][backLabel_index.get(branches_with_placements.get(j))-1]);
								System.out.println("hB: "+half_branch_length.get(branches_with_placements.get(j)));
								System.out.println("lca: "+lca);
								System.exit(0);
							}
						}
						value = branch_matrix[i2][j2];
					}
					float p_i = branch_weights.get(branches_with_placements.get(i)).floatValue();
					float p_j = branch_weights.get(branches_with_placements.get(j)).floatValue();
					score += p_i*p_j*value/total_tree_length; //EDPL formular
				}
			}
			return 1.0f-score;
		}
		else{
			return 1.0f;
		}
	}
	
	public float calculateScore(String name, ClassificationParser clp){
		query_name = name;
		query_locations = clp.getNameLocations(query_name);
		query_locations = sortByOccurrenceInTheTree(query_locations);
		float score = 0.0f;	
		HashMap <String,Double> branch_weights = clp.getLocationsWeights(query_name);
		ArrayList <String> branches_with_placements = query_locations;
		if (branches_with_placements.size() > 1){
			calculateRMQs();  // build the range minimum queries for the lca requests
			for(int i=0; i < branches_with_placements.size()-1; i++){
				int i2 = getIndexI(branches_with_placements.get(i));
				for (int j = i+1; j < branches_with_placements.size(); j++ ){
					int j2 = getIndexJ(branches_with_placements.get(j),i2);
					float value = 0.0f;
					// if score is already  present in the matrix, then take it
					if (branch_matrix[i2][j2] > 0.0f){
						value = branch_matrix[i2][j2];
					}
					// else calculate score and write it into the matrix
					else {
						
						float lca = calculateLCA(i,j);
//						if (query_name.equals("GIJMJ8F04EPGBN_4_P1M+N-E1c")){
//							System.out.println(aToS(query_locations));
//							System.out.println(aToS(lca_is_marked));
//							System.out.println(aToS(rmqs_sums));
//							System.out.println(aToS(rmqs_names));
//							System.out.println(aToS(euler_pathway));
//							System.out.println(aToS(euler_node_pathway));
//							calculateLCAWithPrint(i, j);
//						}
						
						if (lca < 0.0f){ // one of the marked nodes is the lca, then lca = -1.0
							branch_matrix[i2][j2] = Math.abs((branch_matrix[0][i2-1]-half_branch_length.get(branches_with_placements.get(i))) - (branch_matrix[0][backLabel_index.get(branches_with_placements.get(j))-1] - half_branch_length.get(branches_with_placements.get(j))));
							if (branch_matrix[i2][j2]<0.0){
								System.out.println();
								System.out.println("-lca-"+query_name+";"+branches_with_placements.get(i)+"-----");
								System.out.println(branch_matrix[0][i2-1]);
								System.out.println(half_branch_length.get(branches_with_placements.get(i)));
								System.out.println(branch_matrix[0][backLabel_index.get(branches_with_placements.get(j))-1]);
								System.out.println(half_branch_length.get(branches_with_placements.get(j)));
								System.out.println("----------------");
								System.exit(0);
							}
						}
						else{
							
							branch_matrix[i2][j2] = branch_matrix[0][i2-1] - half_branch_length.get(branches_with_placements.get(i))+ branch_matrix[0][backLabel_index.get(branches_with_placements.get(j))-1] - half_branch_length.get(branches_with_placements.get(j))- 2*lca;
							if (branch_matrix[i2][j2]<0.0 ){
								System.out.println();
//								System.out.println("j2: "+j2);
//								System.out.println("j: "+ backLabel_index.get(branches_with_placements.get(j)) );
//								System.out.println("i2: "+i2);
//								System.out.println("i: "+ backLabel_index.get(branches_with_placements.get(i)) );
//								System.out.println(bToS(branch_matrix[i2]));
								System.out.println("-----"+query_name+";"+branches_with_placements.get(i)+";"+branches_with_placements.get(j)+"-----");
								System.out.println("S: "+branch_matrix[i2][j2]);
								System.out.println("RA: "+branch_matrix[0][i2-1]);
								System.out.println("hA: "+half_branch_length.get(branches_with_placements.get(i)));
								System.out.println("RB: "+branch_matrix[0][backLabel_index.get(branches_with_placements.get(j))-1]);
								System.out.println("hB: "+half_branch_length.get(branches_with_placements.get(j)));
								System.out.println("lca: "+lca);
								System.exit(0);
							}
						}
						value = branch_matrix[i2][j2];
					}
					float p_i = branch_weights.get(branches_with_placements.get(i)).floatValue();
					float p_j = branch_weights.get(branches_with_placements.get(j)).floatValue();
					score += p_i*p_j*value/total_tree_length; //EDPL formular
				}
			}
			return 1.0f-score;
		}
		else{
			return 1.0f;
		}
	}
	
	
	private ArrayList<String> sortByOccurrenceInTheTree(ArrayList<String> labels){
		ArrayList<String> tmp = new ArrayList<String>();
		
		// sorts the labels by their occurrence within the tree
		while (!labels.isEmpty()){
			int min_index =backLabel_index.get(labels.get(0));
			String label = labels.get(0);
			int index = 0;
			for(int j = 0; j < labels.size();j++){
				if (min_index > backLabel_index.get(labels.get(j))){
					min_index = backLabel_index.get(labels.get(j));
						label = labels.get(j);
						index = j;
				}
			}
			labels.remove(index);
			tmp.add(label);
		}
		labels = tmp;
		return labels;
		
	}
	private void  calculateRMQs(){
		lca_is_marked.clear();
		rmqs_sums.clear();
		rmqs.clear();
		rmqs_names.clear();
		mark_euler_tour(); //marks the branches with placements
//		if (query_name.equals("GIJMJ8F03C8929_3_T2p_M+N-E1a")){
//			System.out.println(aToS(marked_euler_tour));
//			System.out.println(aToS(euler_pathway));
//			System.out.println(hToS(backLabel_index_euler_tour));
//		}
		float sum = 0.0f;
		int min_level = 999999999;
		float min_level_sum = euler_tour.get(0);
		boolean started = false;
		int rmq_index = 0;
		int index_of_last_marked_node = -1;
		String lca_name = euler_node_pathway.get(0);
		for (int i = 0; i< euler_tour.size(); i++){
		
			sum = sum+euler_tour.get(i);
			
			
			if (marked_euler_tour.get(i)){ // if node is marked, unmark
				marked_euler_tour.set(i, false);
				if (started){  // no calculations, until the second marked node has been reached	
					if (index_of_last_marked_node == rmq_index) { // check if the first of the marked nodes is the lca of both.
						lca_is_marked.add(true);
					}			
					else if (levels_euler_tour.get(i) < min_level){ // check if the second of the marked nodes is the lca of both.
						// refresh rmq data
						rmq_index = i;
						min_level_sum = sum; 
						lca_name = euler_node_pathway.get(i);
						lca_is_marked.add(true);
					}
					else{
						lca_is_marked.add(false);
					}
					rmqs.add(euler_node_path.get(rmq_index));
					rmqs_sums.add(min_level_sum); // score of the lca between this marked node and the previous one
					rmqs_names.add(lca_name);
					min_level = levels_euler_tour.get(i); // set the min level to the current node for the next run
					min_level_sum = sum; // set the score to the score of the current node
					lca_name = euler_node_pathway.get(i);
					rmq_index = i; // set the next lca index temporary on the current node
				}
				index_of_last_marked_node = i;
				started = true;	
			}
			if (min_level > levels_euler_tour.get(i) && started){
				min_level = levels_euler_tour.get(i);  // get the minimal treelevel between the first marked node and the second
				min_level_sum = sum;  // score at this location
				rmq_index = i; // the index of the current lca between the first marked node and the second
				lca_name = euler_node_pathway.get(i);
			}
		}
	
	}
	
	private void mark_euler_tour(){
		marked_branches_sequence.clear();
		marked_branches_lengths.clear();
		marked_nodes_half_branch_length.clear();
		names.clear();
		
		
		ArrayList <Integer> indeces = new ArrayList<Integer>();
		for (int i = 0; i < query_locations.size(); i++){
			int index = backLabel_index_euler_tour.get(query_locations.get(i));
			marked_euler_tour.set(index, true);
			indeces.add(index);
		}
		Collections.sort(indeces);
		for (int i = 0; i<indeces.size(); i++){
			marked_branches_sequence.add(euler_pathway.get(indeces.get(i)));
			marked_branches_lengths.put(euler_pathway.get(indeces.get(i)), euler_tour.get(indeces.get(i))/2.0);
			marked_nodes_half_branch_length.add(euler_tour.get(indeces.get(i))/2.0);
			names.add(euler_pathway.get(indeces.get(i)));
		}
	}
	
	private int getIndexI(String label){
		int index = backLabel_index.get(label);
		return index;
	}
	private int getIndexJ(String label, int i){
		int index = backLabel_index.get(label)-1-i;
		return index;
	}

	
	private float calculateLCA(int i, int j){
		float min = rmqs_sums.get(i);
		float lca = rmqs.get(i);
		String lca_name = rmqs_names.get(i);
		int index_of_lca = i;
		for (int k = i; k<j; k++){
			if ((min > rmqs_sums.get(k)) && (!lca_name.equals(rmqs_names.get(k)))){
				min = rmqs_sums.get(k);
			    lca = rmqs.get(k);
			    lca_name = rmqs_names.get(k);
			    index_of_lca = k;
			}
		}
		if (lca_is_marked.get(index_of_lca)){
			return -1.0f;
		}
		else{
			return min;
		}
		
	}
	
	private void calculateLCAWithPrint(int i, int j){
		System.out.println(i+ " : "+ j);
		float min = rmqs_sums.get(i);
		float lca = rmqs.get(i);
		String lca_name = rmqs_names.get(i);
		int index_of_lca = i;
		for (int k = i; k<j; k++){
			if ((min > rmqs_sums.get(k)) && (!lca_name.equals(rmqs_names.get(k)))){
				min = rmqs_sums.get(k);
			    lca = rmqs.get(k);
			    index_of_lca = k;
			}
		}
		System.out.println("index of lca: "+index_of_lca);
		if (lca_is_marked.get(index_of_lca)){
			System.out.println(-1.0f);
		}
		else{
			System.out.println("min: "+min);
		}
		System.out.println();
	}
	
	private void getLongestAverageAndShortestPath(){
		ArrayList<Float> leaves = new ArrayList<Float>();
 		float sum = 0.0f;
		int min_level = 999999999;
		float min_level_sum = euler_tour.get(0);
		boolean started = false;
		int rmq_index = 0;
		ArrayList <String> branches = new ArrayList<String>();
		int index_of_last_marked_node = -1;
		for (int i = 0; i< euler_tour.size(); i++){
			
			sum = sum+euler_tour.get(i);
			if (marked_leaves_euler_tour.get(i)){ // if node is marked, unmark
//				System.out.println("name: "+euler_pathway.get(i)+"mark: "+marked_leaves_euler_tour.get(i)+"; "+euler_tour.get(i)+"; "+sum+" "+min_level+" "+min_level_sum);
				marked_leaves_euler_tour.set(i, false);
				leaves.add(sum);  //distance from the root to the marked node
				branches.add(euler_pathway.get(i));
				if (started){  // no calculations, until the second marked node has been reached
					if (index_of_last_marked_node == rmq_index){ // check if the first of the marked nodes is the lca of both.
						lca_is_marked.add(true);
					}
					else{
						lca_is_marked.add(false);
					}
					
					this.rmqs_sums.add(min_level_sum); // score of the lca between this marked node and the previous one
					rmqs_names.add(euler_pathway.get(rmq_index));
					this.rmqs.add(node_path_euler_tour.get(rmq_index)); // local branch length of the lca between this marked node and the previous one
					min_level = levels_euler_tour.get(i); // set the min level to the current node for the next run
					min_level_sum = sum; // set the score to the score of the current node
					rmq_index = i; // set the next lca index temporary on the current node
				}
				index_of_last_marked_node = i;
				started = true;	
			}
			if (min_level > levels_euler_tour.get(i) && started){
				min_level = levels_euler_tour.get(i);  // get the minimal treelevel between the first marked node and the second
				min_level_sum = sum;  // score at this location
				rmq_index = i; // the index of the current lca between the first marked node and the second
			}
		}
		float rmq = 0.0f;
		float longest = 0.0f;
	    for (int i = 0; i < leaves.size()-1;i++){
	    	int i2 = getIndexI(branches.get(i));
	    	for (int j = i+1; j < leaves.size();j++){
	    		int j2 = getIndexJ(branches.get(j),i2);
	    		float path_score_ij = 0.0f;	
	    		
	    		rmq = calculateLCA(i,j); 
	    		float lca_path = rmq;
	    		// marked nodes are never lcas in this case
	    		if (leaves.get(i)+leaves.get(j) - 2.0 * lca_path < -1.00001){    // due to floating point arithmetics
	    			System.out.println("Error: Negative distance score: "+ (leaves.get(i)+leaves.get(j) - 2.0 * lca_path));
	    			System.out.println("i: "+leaves.get(i));
	    			System.out.println("j: "+leaves.get(j));
	    			System.out.println("lca_path: "+lca_path);
	    			
	    			System.exit(1);
	    		}
	    		branch_matrix[i2][j2] = leaves.get(i)+leaves.get(j) - 2.0f * lca_path ;
	    		path_score_ij = branch_matrix[i2][j2] ;
	    		if (longest < path_score_ij){
					longest = path_score_ij;
				}
	    	}
	    }
		double branch_sum = 0.0;
		for (int i = 0; i< euler_tour.size(); i++){
			if (euler_tour.get(i) > 0.0 ){
				branch_sum = branch_sum + euler_tour.get(i);
			}
		}
		this.all_branch_sum = branch_sum;
		this.longest_path = longest;
	}
	
	private String matrixToString(){
		String out = "";
		for(int i = 0; i < branch_matrix.length; i++){
			for(int j = 0; j< branch_matrix[i].length; j++){
				out = out+branch_matrix[i][j]+" ";
			}
			out = out+"\n";
		}
		
		return out;
	}
	
}
