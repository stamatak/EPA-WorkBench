package ml;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

public class BipartitionScoreWeighted {

	HashMap <String, HashMap<String,Float>> branch_query_PlacementsBeneath = new HashMap<String, HashMap<String,Float>>(); 
	HashMap <String,Double> location_confidence = new HashMap<String, Double>();
	HashMap <String,Integer> location_branchesBeneath = new HashMap<String, Integer>();
	int all_branches = 0;
	
	public BipartitionScoreWeighted(LN root, ClassificationLikelihoodParser clp){
		getNodesPlacements(root,clp);
		int u = 0;
		Set <String> branches = branch_query_PlacementsBeneath.keySet();
		for (String branch : branches){
			u++;
			Set<String> queries = branch_query_PlacementsBeneath.get(branch).keySet();
			float score = 0.0f;
			// values for normal distribution p,n,k
			float p = (float)location_branchesBeneath.get(branch)/(float)(all_branches-1);
			if (branch == "IROOT"){
				p = 1.0f;
			}
			for(String query : queries){
				HashMap<String,Double> branches_with_placements = clp.getLocationsWeights(query);
				
				float n = 0.0f;
				if (branches_with_placements.containsKey(branch)){
					n = clp.getNameLocations(query).size()-1.0f;
				}
				else{
					n = clp.getNameLocations(query).size();
				}
				float k = branch_query_PlacementsBeneath.get(branch).get(query);
				float conf = calculateConfs(p, n, k);
				if (conf > 1.0001f){
				System.out.println("n: "+n+" , k: "+k+" , p: "+p+ " => "+conf+" "+query+"("+n+")" );
				}	
				score += conf;			
			}
			location_confidence.put(branch, Double.valueOf(score)/((double)queries.size()));
		}
		
	}
	
	public BipartitionScoreWeighted(LN root, ClassificationParser clp){
		getNodesPlacements(root,clp);
		int u = 0;
		Set <String> branches = branch_query_PlacementsBeneath.keySet();
		for (String branch : branches){
			u++;
			Set<String> queries = branch_query_PlacementsBeneath.get(branch).keySet();
			float score = 0.0f;
			// values for normal distribution p,n,k
			float p = (float)location_branchesBeneath.get(branch)/(float)(all_branches-1);
			if (branch == "IROOT"){
				p = 1.0f;
			}
			for(String query : queries){
				HashMap<String,Double> branches_with_placements = clp.getLocationsWeights(query);
				
				float n = 0.0f;
				if (branches_with_placements.containsKey(branch)){
					n = clp.getNameLocations(query).size()-1.0f;
				}
				else{
					n = clp.getNameLocations(query).size();
				}
				float k = branch_query_PlacementsBeneath.get(branch).get(query);
				float conf = calculateConfs(p, n, k);
				if (conf > 1.0001f){
				System.out.println("n: "+n+" , k: "+k+" , p: "+p+ " => "+conf+" "+query+"("+n+")" );
				}	
				score += conf;			
			}
			location_confidence.put(branch, Double.valueOf(score)/((double)queries.size()));
		}
		
	}
	
	// gets the amount of placements for all node's underlying subtree and counts all branches of the tree
	private void getNodesPlacements(LN node, ClassificationLikelihoodParser clp){
		all_branches++;
		HashMap <String,Float> query_placements = new HashMap<String, Float>(); // amount of placements that lie in the beneath subtree
		Set <String>  queries = clp.getNames().keySet();
		getAmountOfBranches(node,node.backLabel, clp);
		for (String query : queries){	
			if (node.next.back != null && node.next.next.back != null){
				float placements_left =  ((float)getAmountOfPlacements(node.next.back,node.next.back.backLabel, clp, query,0.0f));
				float placements_right = ((float)getAmountOfPlacements(node.next.next.back,node.next.next.back.backLabel, clp, query,0.0f));
				query_placements.put(query, (placements_left+placements_right));
			}
			
		}
		branch_query_PlacementsBeneath.put(node.backLabel, query_placements);
		
		if (node.next.back != null){
			getNodesPlacements(node.next.back, clp);
		}
		if (node.next.next.back != null){
			getNodesPlacements(node.next.next.back, clp);
		}
	}
	
	private void getNodesPlacements(LN node, ClassificationParser clp){
		all_branches++;
		HashMap <String,Float> query_placements = new HashMap<String, Float>(); // amount of placements that lie in the beneath subtree
		Set <String>  queries = clp.getNames().keySet();
		getAmountOfBranches(node,node.backLabel, clp);
		for (String query : queries){	
			if (node.next.back != null && node.next.next.back != null){
				float placements_left =  ((float)getAmountOfPlacements(node.next.back,node.next.back.backLabel, clp, query,0.0f));
				float placements_right = ((float)getAmountOfPlacements(node.next.next.back,node.next.next.back.backLabel, clp, query,0.0f));
				query_placements.put(query, (placements_left+placements_right));
			}
			
		}
		branch_query_PlacementsBeneath.put(node.backLabel, query_placements);
		
		if (node.next.back != null){
			getNodesPlacements(node.next.back, clp);
		}
		if (node.next.next.back != null){
			getNodesPlacements(node.next.next.back, clp);
		}
	}
	
	
	
	// calculate the confidence scores based on a binomial distribution and the observed placements k for one of the subtrees
	private float calculateConfs( float p, float n, float k ){
		float lh_mass_left = 0.0f;
		float lh_mass_right = 0.0f;
		float alpha = 0.0f;
		
		// calculate phi(x), the probability that k is observed in an interval between -infinity and x in a standard normal distibution)
		float expected = p;
		float sigma_square = p*(1.0f-p);
		float x = (k-expected)/(float)(Math.sqrt(sigma_square));
		lh_mass_left = 0.5f*(1+erf(x/Math.sqrt(2.0)));
		lh_mass_right = 1.0f - lh_mass_left ;
		
		if (lh_mass_left < lh_mass_right){
			alpha = lh_mass_left;
			float lh_n = (float)(binomialCoefficient(n,n)*Math.pow((double)p, (double)n)*Math.pow(1.0-(double)p, (double)(n-n)));
			if (0.5 > alpha  && lh_n < alpha){
				alpha *=2;
			}
		}
		else{
			float lh_0 = (float)(binomialCoefficient(n,0)*Math.pow((double)p, (double)0)*Math.pow(1.0-(double)p, (double)(n)));
			alpha = lh_mass_right;
			if (0.5 > alpha && lh_0 < alpha){
				alpha *=2;
			}
		}
		alpha = ((float)((int)(alpha*10000f)))/10000f;
		if (1.0f - alpha < 0.0f ||  1.0f - alpha > 1.0f){
			System.out.println(n+ " "+k+" "+p);
			System.out.println();
			System.out.println(lh_mass_left+ " : "+lh_mass_right);
			System.out.println("Error: Bad alpha value: "+alpha);
			System.exit(1);
			
		}
		return 1.0f - alpha;		
	}
	
	// Error function
	private float erf(double x){
		float a = 0.140012f;   //approximation
		float value  = (float)( (x/Math.abs(x)) * Math.sqrt( 1.0-Math.exp( -1.0*x*x *  (((4/Math.PI)+a*x*x)/(1+a*x*x)) ) ) ); //Error Function approximation 
		return value;
	}
	
	private float binomialCoefficient(float n, float k){
		long binom = 1;
		if (k > n/2){
			k = n-k;
		}
		for(int i = 1; i <= k; i++){
			binom *= (n+1-(float)i)/(float)i;
		}
		return (float)binom;
	}
	
	private float getAmountOfPlacements(LN node, String branch, ClassificationLikelihoodParser clp, String query, float amount){
		if (clp.getLocationsWeights(query).containsKey(node.backLabel)){
			amount += clp.getLocationsWeights(query).get(node.backLabel);
		}
		if (node.next.back != null){
			amount = getAmountOfPlacements(node.next.back, branch, clp, query, amount);
		}
		if (node.next.next.back != null){
			amount = getAmountOfPlacements(node.next.next.back, branch, clp, query, amount);
		}
		return amount;
	}
	
	private float getAmountOfPlacements(LN node, String branch, ClassificationParser clp, String query, float amount){
		if (clp.getLocationsWeights(query).containsKey(node.backLabel)){
			amount += clp.getLocationsWeights(query).get(node.backLabel);
		}
		if (node.next.back != null){
			amount = getAmountOfPlacements(node.next.back, branch, clp, query, amount);
		}
		if (node.next.next.back != null){
			amount = getAmountOfPlacements(node.next.next.back, branch, clp, query, amount);
		}
		return amount;
	}
	
	private void getAmountOfBranches(LN node, String branch, ClassificationLikelihoodParser clp){
		if (location_branchesBeneath.containsKey(branch)){
			location_branchesBeneath.put(branch,location_branchesBeneath.get(branch)+1);
		}
		else {
			location_branchesBeneath.put(branch,1);
		}
		if (node.next.back != null){
			getAmountOfBranches(node.next.back, branch, clp);
		}
		if (node.next.next.back != null){
			 getAmountOfBranches(node.next.next.back, branch, clp);
		}
	}
	
	private void getAmountOfBranches(LN node, String branch, ClassificationParser clp){
		if (location_branchesBeneath.containsKey(branch)){
			location_branchesBeneath.put(branch,location_branchesBeneath.get(branch)+1);
		}
		else {
			location_branchesBeneath.put(branch,1);
		}
		if (node.next.back != null){
			getAmountOfBranches(node.next.back, branch, clp);
		}
		if (node.next.next.back != null){
			 getAmountOfBranches(node.next.next.back, branch, clp);
		}
	}
	
	
	public HashMap <String,Double> getLocationConfidence(){
		return location_confidence;
	}
	
	private float roundFloat(float f){
		int i = (new Float(f)).intValue();
		String s = String.valueOf(f);
		int sub1 = 0;
		for (int k = 0; k < s.length() ; k++){
			if (s.substring(k,k+1).equals(".")){
				sub1 = Integer.parseInt(s.substring(k+1,k+2));
			}
		}		
		if (sub1 > 4){
			return (float) (i+1);
		}
		return (float)i;
	}
}
