package test;

public class TestChild extends TestBase {

}
